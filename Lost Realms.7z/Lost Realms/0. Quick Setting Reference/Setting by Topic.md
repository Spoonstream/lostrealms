**Aetherium**
 : the plane of pure magic and thought. It surrounds the material plane and magic passes through the barrier separating the two and then outward into the twelve outer planer domains. Mortals have only been able to glimpse into the Aetherium and at great cost. 
 
 The only known event of mortals travelling to the Aetherium, are the Eternals, although it is unknown how they accomplished this. As there are mortals who share connection to the eternals, through ascendancy rites possessed now by the most powerful guilds, it can be assumed that passage through or to the Aetherium must be possible, but no method or ability has been discovered as of yet. 

**Bac'Dannon**
 : 

**Chapter Company's**

**Dragons**
 : 


**En'nui'al**
 : 

**Eternals, The**

**Gerdanya (Grr-dayin-ya)**
 : 

**Guilds (System, The)**
 : 

**Mor'Rokai (Morr-RO-KEI)**



**Ozrevon (Oh-ZRA-VON)**
 : 

**Sundering, The**
 : 

