
# OCC Section

### Schedule

### Food

### PVP

### Veils

### Lines



# Concept

## Types of Charter Companies
- Explorers and Artifact Hunter's
	- Traveling, Dungeon Crawling, and Survival.
- Lore Seeker's 
	- Investigation, Research, Occult, and "re-appropriating" Lost items
- Defenders of the Frontier
	- Social and Political issue's, Intrigue, Diplomacy and Warfare.
- Rebels and Outlaws.
	- Social Survival, Crime, and Gorilla Warfare.


### Explorers 

#### Description

#### Company Ability

#### Downtime Action

#### Bonds

#### Milestones

#### Drives


### Seekers of the Lost

#### Description

#### Company Ability

#### Downtime Action

#### Bonds

#### Milestones

#### Drive


### Defenders of the Frontier

#### Description

#### Company Ability

#### Downtime Action

#### Bonds

#### Milestones

#### Drives


### Rebels and Outlaws 

#### Description


#### Company Ability
- Rebels 
	- +2 Circumstance Bonus for Recall Knowledge Checks (Creature Identification) vs NPC's that are members of a higher social class.
- Outlaws
	- +2 Circumstance Bonus for Recall Knowledge Checks (Creature Identification) vs Figures of Authority.
- Mercenaries
	- +2 Circumstance Bonus for Recall Knowledge Checks (Creature Identification) vs Members of the military or City/Town Guard



#### Downtime/Exploration Bonus

- Rebels
	- Downtime Bonus Subsist
	- Exploration: Repair
- Outlaws
	- Create Forgery
	- Avoid Notice
- Mercenaries 
	- 
	- Follow the Expert

#### Bonds

Outlaws Code
- Don't leave anyone out to dry.
- Never steal from the party.
- Don't be a snitch.

Rebels Oath
- No Collaborators 
- Never keep a secret that can get the group in danger
- Us or with them. There is no middle ground.

The Mercenary Creed
- "No women, No Children" (Prohibition against a type of action)
- Honor our agreements. 
- Trial by combat. (group conflict's are resolved in a specific manner).

#### Quest Log




#### Drives


