

### Sandbox Campaign video 

##### google Tables
https://docs.google.com/spreadsheets/d/1foqeR8NHNjjgA-CeHlHV8m-GSO83MB-MYAkqqLkyPto/edit#gid=0


##### Quest and XP
- XP is Rewarded Principally from Quest written in the Quest Log or Milestone Section.
- 


##### Proficiency without Level
- Proficiency bonus is +1
- Untrained is 0 not -2.
- Proficiency bonus for level is applied to treat wounds. 
- Modified Simple DC's and DC's by level 
- "Boss" Monsters recieve a bonus to checks and DC's 
	- -1 for "mini-bosses"
	- -2 for "Bosses"


##### Recall Knowledge (For Creature Identification)
- Added Success: Character learns the level and traits of target identified. 
- Success grants one of the additional following pieces of information.
	- Highest defense
	- Lowest Defense
	- All immunities and Resistances
	- All Weakness.
	- Any one relevant special ability, as well as how many special abilities they possess. 
- Critical Success grants two pieces of additional information. 

##### Hero Points
- Characters can spend hero points before a roll to gain Fortune effect.

## Things to look Into
- Rooms and Teams from ultimate campaign PF1e (use 10% of the listed gold cost to adjust for PF2e)
- **DC's in the Game Core**
- Free Archetype


## Problems to solve 
- **Problem**: 
	- automatic bonus's are expected.
	- progression has a mixture of high magic and low magic.
	- Gold is a meta currency for progression...how can we make it meaningful.
	- What relics or gear options need to be included.

 