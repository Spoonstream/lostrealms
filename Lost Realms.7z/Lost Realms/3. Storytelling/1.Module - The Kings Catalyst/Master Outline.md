
## General Concept:
*Entering the Zone. It is the beginning of the reclaimation. Things will begin to awaken and conflicts will arise as the two "worlds" that have been seperated for almost two centuries clash. Characters enter a conflict that is about to happen between several factions. 
[[Gerdanya]]  and [[Mal'Kryinnis]]. The factions of [[Mal'Kryinnis]] and those that influence them. The Sorcerer's Conscilium , the Kabal of the Veil, and the [[The Magisters]]. The Guild and the Alchemists Union. 
In the Middle of this conflict and ancient power will awaken. This evil will seek to reclaim what is theirs, the lands of Enarynn, beginning with [[Mal'Kryinnis]]. This will be instigated by a small cult calling themselves, the Creed of the Chosen.*      

The players are going to journey from [[Gerdanya]], to Ozrevon and across the Boundary at the behest of the Alchemists Union. They will become embroiled in a power struggle between multiple factions, as a an ancient evil begins to surface.

## Factions and Antagonists.

**Gerdanya:** 
A good king trying to retain his right to rule, is trying to expand his nation, mostly at the urging. In reality he seeks to reconcile with [[Mal'Kryinnis]] and hopes to delute the influence of the other greedy Lords of [[Gerdanya]].

He has sent charter companies, led by General Daerylin to secure the territory around which a Gateway tower is being built. 

**Ozrevonia**
The duchess seeks to reunite her nation with its people and establish a rightful heir. She is allied with the monarch but also using him, to gain access to the ability to issue a charter for her own purposes. 

The monarch believes that she is sending someone across the border via a way that she knows about. She desire to send someone to acquire a soveriegn relic, at which point a claim and [[Mal'Kryinnis]] can lay claim as a sovereign nation (the first on the other side of the boundary) 

**General Daerylin**
Blood thirsty Warlord who seek s to carve out his own niche and overthrow the Gerdanian Monarch.

The Monarch however implicitly trusts the General, which is why he sent him to begin with and suspects nothing. 

**Castigan Riley - Guild Magistrate.**
Was in charge of ferreting out the Alchemist's Union. He is aware of Fergus's operations and became aware of Duchesses conspiracy with Fergus against the King. 

He has informed the King about the action, and secretly hopes to double cross him, instead supporting Dealyrin's Coup. He plan's to use his alliance and oppurtunity of a second gateway to gain greater favor. 

He had Captain Allister arrested so he could get to Marland first. 

**The Vedragar**
Circle of Druids tied to old Mal'Kryinnis and defending the people of Mal'Kryinnis. 

They are more concerned with the Mal'Kryinnian People, both because of political influence, but because of historical symbiotic relationship. 

They believe that the Ozrevonian people turned their backs and are more or less the enemy.

Seek to meet the Gerdanyian an expansion and sabatage any gateway. (need to work on their motivation)

**The Silent Sigil**
Magic users from the sovereign kingdoms  that are attempting to build an underground gateway. They are in reality a secret arm of the Consulate, seeking to acquire the ability to operate outside of Guild Authority purview. 

**Boundary Wizards**
Mages that exist beyond the boundary working with the Druid's, they are seeking to stop the [[Gerdanya]] and the invasion. They to have divined that the [[Gerdanyian]] military will be crossing. They have been guarding the ruins underneath the boundary and the reason why the Alchemists alliance knows about the passage underneath the Titan's teeth. 

**Alchemist's Alliance**

They are attempting to subvert the Guilds and guild authorities control by establishing a smuggling route and expand the capabilities of Alchemy. They had approached Erina Kostrova, after Marland, one of their operatives in Ozrevon, informed them about a passage underneath the Titans Teeth, that led through to the Boundary. 

They proposed that she issue a charter for them and they would cross with an expedition that embarked from [[Mekh'Reban]] and headed north. Once they had established an settlement, they could create a smuggling network, that Erina could use, to re-establish ties with the former kingdom. 

**The Mal'Krynnian People**

Three general political factions within the area, made up of local leaders from the regions villages. None have any political or military ability to command each other and up until recently they were at war for over a century. When the Gerdanian expidetion arrived to the south they aligned, but the alliance is fragile, one sides with the "Druid Lords", one faction has aligned itself with the Alchemists Union, and one has aligned itself openly with [[Gerdanya]]. 

**Guardians of Su'kwe'Relen**
Collection of Wizards and Sorcerers that guard society from the Su'kwe, a forgotten civilization that imprisoned underneath the region that is currently known as Mal'Krynnis. They began as a order of conscilium wizards that uncovered the presence of their prison during the Malediction. Since the Boundary division, they have been involved in influencing the affairs of [[Mal'Kryinnis]] and to a lesser extent and only more recently the affairs of Ozrevon. 


**"Anicent Evil"**

Long ago the sovereign relic for the kingdom of mal'krynnis was hidden in within an ancient ruin that now lies underneath the boundary. Held within a vault that was built by the "Elder Fey" This was done because a corruption had spread throughout the kingdom and an ancient spirit enemy was seeking to awaken. The Ruin has magics that has protected it from boundary and kept the ancient evil from surfacing. The Boundary has worn down the eldritch enchantments on those protections. Now the passage will disappear soon (very soon).


## Events and Background


It is the onset of the Reclamation. With the Southern Soveriegn having a major influence the other factions of the Soveriegn Conclave are scrambling...searching for alternate means to enter the Boundary. 

The Nation of [[Gerdanya]]'s Monarch has recieved a vision (through a magical pool of water), of a passage opening. Despite the popular belief that the pool ordains the future often, in reality most past monarch have lied about the pool prophesizing, but the reality is the pool does not communicate often, but when it does, it always comes to pass.


## Theme: 

Inheritence

This campaign is initially about inheritence, debts and legacy. We are all the products of those that come before us, and for many we spend our entire lives working to pass down something to the next generation. 
This motivation is central to our character as humans. 


Chekov's Gun's

[[Gerdanya]] 
 [[Mal'Kryinnis]] and [[Ozrevon]] 
 The Guild 
 [[The Magisters]] 
 The Sorcerer's Conscilium 
 [[The Boundary]] 
 The "Conflict"
 Soveriegn Relics
  


**Passage Day**

- Is celebration of official command of King Mac'graven, to General Daerylin, to venture forth with the armies of [Gerdanya](app://obsidian.md/Gerdanya) to the Boundary, where a passage was forseen by the Oracle to open.

**The Oracle**

- The Oracle is spirit inhabating a pool of water. A remnant of the ancient times, it serves as the arbitrator for succession, and it's prophetic visions often serve to advise the King what to do. (the king is the only one who can access it.)

**Captain Allister**

- Was captured and arrested on charges of smuggling contraband items.
- The charges are false but Fargus is concerned because the Captain is apart of the Alchemist's Union and he fears that someone knows about their plans and is interfering.
- Coupled with the fact that he has not received word back from Marland (the contact in Ozrevon), he fears that transport will be impossible.




> [!NOTE] > Fargus Brogayn
> [NE](https://2e.aonprd.com/Rules.aspx?ID=95) [Medium](https://2e.aonprd.com/Rules.aspx?ID=445) [Human](https://2e.aonprd.com/Traits.aspx?ID=90) [Humanoid](https://2e.aonprd.com/Traits.aspx?ID=91)   
**Source** [_Gamemastery Guide pg. 210_](https://2e.aonprd.com/Sources.aspx?ID=22)  
**Perception** +**6**  
**Languages** [Common](https://2e.aonprd.com/Languages.aspx?ID=1)  
**Skills** [Accounting Lore](https://2e.aonprd.com/Skills.aspx?ID=8) +**8**, [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**5**, [Crafting](https://2e.aonprd.com/Skills.aspx?ID=4) +**8**, [Deception](https://2e.aonprd.com/Skills.aspx?ID=5) +**8**, [Diplomacy](https://2e.aonprd.com/Skills.aspx?ID=6) +**6**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**6**, [Society](https://2e.aonprd.com/Skills.aspx?ID=14) +**6**, [Stealth](https://2e.aonprd.com/Skills.aspx?ID=15) +**5**, [Thievery](https://2e.aonprd.com/Skills.aspx?ID=17) +**5**, [Underworld Lore](https://2e.aonprd.com/Skills.aspx?ID=8) +**10**  
**Str** +0, **Dex** +3, **Con** +0, **Int** +4, **Wis** +2, **Cha** +4  
**Fence's Eye** Fences live by their ability to recognize a viable trade. They can use [Underworld Lore](https://2e.aonprd.com/Skills.aspx?ID=8) to identify an item's value and [Identify Magic](https://2e.aonprd.com/Actions.aspx?ID=24) on an item. They gain a +2 circumstance bonus to Underworld Lore checks when doing so, and to Underworld Lore checks to determine whether an item was stolen, whether a stolen item would be too recognizable to easily move, and who would be interested in purchasing such an item.  
**Items** [_bird feather token_](https://2e.aonprd.com/Equipment.aspx?ID=244), [dagger (10)](https://2e.aonprd.com/Weapons.aspx?ID=3), [disguise kit](https://2e.aonprd.com/Equipment.aspx?ID=19), [lesser darkvision elixir](https://2e.aonprd.com/Equipment.aspx?ID=89), [lesser smokestick (2)](https://2e.aonprd.com/Equipment.aspx?ID=135), [shortsword](https://2e.aonprd.com/Weapons.aspx?ID=43), [thieves' tools](https://2e.aonprd.com/Equipment.aspx?ID=58 
**AC** **15**; **Fort** +**4**, **Ref** +**7**, **Will** +**10**  
**HP** 70 
**Speed** 25 feet  
**Melee** [one-action] shortsword +**7** [[+3/-1](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [finesse](https://2e.aonprd.com/Traits.aspx?ID=179), [versatile S](https://2e.aonprd.com/Traits.aspx?ID=200)), **Damage** 1d6+5 piercing
**Melee** [one-action] dagger +**7** [[+3/-1](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [finesse](https://2e.aonprd.com/Traits.aspx?ID=179), [versatile S](https://2e.aonprd.com/Traits.aspx?ID=200)), **Damage** 1d4+5 piercing
**Ranged** [one-action] dagger +**7** [[+3/-1](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [thrown 10 feet](https://2e.aonprd.com/Traits.aspx?ID=195), [versatile S](https://2e.aonprd.com/Traits.aspx?ID=200)), **Damage** 1d4+2 piercing
**Quick Rummage** [one-action] The fence always has a few items close at hand. The fence Interacts to draw a weapon or item that takes a single action to activate, and then Strikes with the weapon or Activates the Item.**Scoundrel's Feint** When the fence successfully [Feints](https://2e.aonprd.com/Actions.aspx?ID=48), their target is [flat-footed](https://2e.aonprd.com/Conditions.aspx?ID=16) against the fence's attacks until the end of the fence's next turn. On a critical success, the target is flat-footed against all attacks until the end of the fence's next turn.**[Sneak Attack](https://2e.aonprd.com/MonsterAbilities.aspx?ID=34)** The fence deals an extra 2d6 precision damage to [flat-footed](https://2e.aonprd.com/Conditions.aspx?ID=16) creatures.


## Last Watch




