
## OOC:
- Path builder is two separate costs (1 for computer and 1 for phones). This will make referencing characters more difficult. it will also lead to players not being able to have accurate sheet. The character sheet issue needs to be solves...Physical sheets and a back up method. 
- Thaxton was using the computer so my notes are going to be OSR because I don't have access to my obsidian as a guarantee (at least until i solve that problem).
- Language is gonna be way more important that I anticipated. Maps then language.
- The time spent in [[1. Setting/1. Lum'rin'el Locations/The Sovereign Kingdoms/Bac'Rudranyr Peninsula/Gerdanya/Gerdanya]] is best spend about about the theme of narratives. 
- I couldn't access my obsidian because of the above and some sort of issue with transporting the database. 
- Printouts didn't happen like I wanted.
- Nicole reminded me that she can print anything (black and white) as long as I contact her before thursday. (printing.trl.org)

## Rules 
- Skill checks
- Cash Rewards
- Buying things.
- Negotiation or Haggling

## Important Reminders/World Building
- Give angela her time for introduction somehow.
- Thaxton's character is from Fallkirk
- I don't have my password or login for Path builder.
- Gerdanian's where (sashes?) embroidered with family emblems called Chewey's.
- Southern Sovereign - Politically allied faction with the Conclave of Sovereign, constisting of geopolitical southern soveriegn sultans and guilds. 
- Guild Authority is the political apperatus of the guilds. Oversee's among other things regulation of the arcane. 

## Scenes 
Nicole: Cimon helped them escape jail
Joe: Grew up with Cimon.
Thaxton: Don't remember thaxtons hook. He is from Fall kirk...they export buffalo?
Xylus:

Met with Fargus Borgun at the Spicy Suace Inn.
Took them down to the speak easy.
Hired them for an expedition across the boundary.
Lady Nostrova issued the Charter.
Nicole stole the scroll case.
They are to meet Lucan Kiteholder
Lucan will pay them  (the standard rate)
They are to travel to Nostravonia 
They will be accompanied by a representative to assist them, Asmodean. 







![[dum_dolan.png]]