


# Rules Reminder 
Perception
Recall ability
Pets
Stealth


# Terms

[[Gateways]] 
[[Gerdanya]]  9 Lords

Marland
Captain Allistor
Last Watch 


# Recap

- Jupia (Angela) and Krastyn(Brian) arrive via boat towards the middle of the morning. 
- They meet Cimmon.
- There was a celebration towards the center of the town.
- Description of the Hearthstone and battles.
- They went to the Spicy Sauce Pub.
- Met Fargus and then were brought downstairs to the others in the group. 
- Fargus asked the others if they could bring them up to speed.

They talked about
- They were hired to go to ozrevon, meet a contact, and then they would cross [[The Boundary]], where they would travel to Nostranovia and meet Lucan Kite holder, at Lucan's Mining Co.
- They would perform tasks and be paid (Jobs that were "less than legal". Then when everything Lucan required of them was finished they would be paid and Lucan as the authorized appointee, could release their charter as an independent one. 
- Cimmon said that they were setting up a smuggling ring and that Fargus was being coy because he was paranoid. 

Fargus Returns
- Questions are raised about how they are to be traveling there (fargus had mentioned that he was leaving for a little bit to sort out new travel arrangements).
- This led to a conversation about Captain Allister being arrested.
- Cimmon said that Allister was normally very careful and good at being appearances. That he didn't drink or get into trouble.
- Threl (Thaxton) asked if Fargus wanted them to break him out. Fargus expressed concerns over drawing attention because he didn't know why the captain has been arrested. 
- Fargus then explained that he had arranged for the parties travel via gateway to the small town of Last Watch. That despite the "passage day" celebrations he was able to acquire a less used but more direct route over land, into the region of Bac'Dannon where Ozrevon was located. They were traveling under the identities of delivering a shipment of supplies to the pub there. 
	- Cimmon had explained that Bac'Dannon, which meant in Can'lyr (the Gerdanian Language) "Backwards Land", had been Annexed at some point after the Boundary had risen. 
- Fargus explained that he feared someone was on to their operation, and that he had lost contact with Marland the person that was to be there contact. He gave the party secured letters, of which were to be opened when they arrived in Ozrevon and could not located Marland or if something had happened to him. 
- They were given travel papers, road passes. a cart with travel supplies, 1 horse (or pony) each and 5 guilders stipend for room board or traveling costs. 
- The group elects to take Cimmon with them rather than asmodean (the person that Fargus mentioned in the previous [[1. Introductions]] )

The Party travel to the [[Gateways]] 
- They depart gather the wagon and horses...the city is much more busy than earlier. The main thorough fare towards the gate is packed full of people, who are gathering at the sides of the road, as though preparing for a parade. 
- The players arrive at the gate tower. a large tower complex with a ring of walls. They go through the entrance and are met by a Gate mage, who checks their papers and then leads them to "one of the older gates".
- along the way they are forces to halt and wait while a military procession passes through, towards the more commonly traveled gate. It has been referenced that higher traffic.
- They catch a glimpse of **General Daelyrin** a large brutish looking figure with a shaved head and scars. He is wearing a very ornate but intimidating armor bearing a pair of wolfs over the shoulders and an uncharacteristically plain cloak that appears to be some sort of fur from an unidentifiable creature. 
- They learn (from talking to the Gate mage leading them) that the King of Gerdanya, has issued a proclamation sending armed military to go beyond the Boundary. That is what passage day and all the fanfare is about. 
	- This is *presumably* by issuing charter's.
- They travel downwards towards the gate. The tower is hollow with large ramps that slowly wind up and down its massive interior. The roof is open allowing the sunlight into it. At the bottom they can see a giant crystal very similar in appearance to a hearthstone, but much much larger, framed in gilded metal that unfolds almost like a lotus. The atmosphere is pulsating with ethereal energies. 
- They travel through the gate, an older looking gate. The gates look similar to the movie stargate, with eldritch runes. 
- Travel through the gate they feel time come to a standstill, a second turns into hours as they feel physics suspend, standing still and traveling at the same time. They feel a sensation of passing through a murky film that almost sickens them. When they ask the Gate-Mage on the other end, he attributed it to the destination gates age. 

Arriving at Last Watch.
- They arrive at last watch, and ask about the sensation. 
- This tower is much older in construction, it being the last tower that Thaelos Fate changer himself constructed, before disappearing. 
- The gate mage apologizes ahead of time, for any destruction to the premise that they see on the way out. He explains that there was an incident, this morning, of someone breeching security and attempting to use magic to access a Gate. They then used magic and harmed those attempting to stop him. He was apprehended however. 
- They are directed to the monument that the tower premise shares. A large memorial dedicated to Thaelos Fate Changer.
- The memorial is sits in a semi spherical large plaza sized room that opens up to over look the high cliffs and the sea. The statue depicts Thaelos as a tall humanoid with figure with elvish features (it is not known but widely believed he was elvish in descent.)
- The statue is almost morose or sad. The statues pose is as though Thaelos is taking one last look before taking a step back as though to turn away.
- On their way out they see one of the gateway chambers is heavily damaged and scarred with blast marks from presumably magics from the altercation. The area has been separated by rope to restrict direct access to the area. 
- 

The Town or Last Watch. 
- They travel out of the tower and down a slightly winding hill to a small walled town of Last Watch. Upon reaching the town square they see a man in a clear large box made of glass or translucent crystal, sitting on top of constructed platform, there is a large space 40 food radius, ringed by rope with guards.
- Inside the box sits a man with bound hands and a large collar (which is presumably a mage collar.)
- One of the guards directly in front of them speaks to them as they enter the space, "halt one step further and the prisoner dies!" 
- Game Ends. 