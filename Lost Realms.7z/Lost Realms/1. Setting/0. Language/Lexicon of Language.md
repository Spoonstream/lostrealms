

#### Can'lyr - [[1. Setting/1. Lum'rin'el Locations/The Sovereign Kingdoms/Bac'Rudranyr Peninsula/Gerdanya/Gerdanya|Gerdane]]
Language
"Bac- or -bac" = Backwards, broken or bent
"-dane" = place or land
"Gurdayr" = to be guarding or guardian


#### Gazyaven (indegenous language of Mal'Krynn and Bac'Dannon) 
Originally named Ozres'stravonia (meaning Place for the orphaned people in older tongue.)
" Ozre-" = thing that is orphaned
"-es" = People
"Stra-" = for/of a people/person
"-vonia" = place


#### Al'Ralni (The First Language)
En'nui'al (ahn - WEE - el)= Usually translated as the "The first people."  The prefix En' translated however means origination, source, or of origin. -nui- is roughly translated as a feeling of either boredom or intense inspiration, but in reality meant both. The prefix/suffix el-/-al is still used in old spoken tongues, as a suffix or prefix, typically as a form of pronoun or as a way to indicate oneself (like saying We (me) must stand).

Lu - Young or concieved 
-m - You shall be 
re-

Enarynn (EN-nar-rin) = "First Kingdom" or "Old Kingdom"
*Lum'rin'el* (LOOM-rin-eL) = Place you shall be conceived.
Luminel = Birthplace
Thae're'al


#### Sakhran ("orcish language")


#### Nequillan (other orcish language)


#### High Speech
English...