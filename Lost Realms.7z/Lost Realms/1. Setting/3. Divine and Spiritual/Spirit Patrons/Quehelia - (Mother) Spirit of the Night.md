Deepest darkest shadow....


Research Links
- https://en.wikipedia.org/wiki/Corvidae
- https://en.wikipedia.org/wiki/Crow
- https://en.wikipedia.org/wiki/Raven
- https://www.mythosblog.org/post/corvids-as-symbols-of-misfortune#:~:text=Corvids%20would%20therefore%20be%20a,their%20bodies%20were%20left%20in.
- https://en.wikipedia.org/wiki/Cultural_depictions_of_ravens
- "All in all, crows represent **death, danger, misfortune, and illness but also rebirth, self-reflection, intelligence, and loyalty**"
	- https://www.birdzilla.com/learn/crow-symbolism-meaning/#:~:text=All%20in%20all%2C%20crows%20represent,%2C%20literature%2C%20and%20popular%20culture.
- [Crow Symbolism and Meaning](https://people.howstuffworks.com/crow-symbolism.htm#:~:text=From%20their%20clever%20problem%2Dsolving,strong%20relationships%20and%20personal%20growth.)
