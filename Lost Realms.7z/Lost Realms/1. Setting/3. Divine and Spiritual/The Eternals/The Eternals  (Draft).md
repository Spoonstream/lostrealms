


# The Eternals



1) The Midwife: Charity, Truth and Fortune 
2) The Maid: Love, Fortune, and Inspiration 
3) The Judge: Law, Protection and Punishment 
4) The Sentinel: Protection, Punishment, and Conflict 
5) The Sage: Truth, Conflict, and Secrets 
6) The Builder: Creation, Fortune, and Misfortune 
7) The Hangman: Punishment, Law, and Death 
8) The Warrior: Conflict, Truth, and Protection 
9) The Explorer: Misfortune, Creation, and Death 
10) The Tyrant: Tyranny, Punishment and Conflict 
11) The Hand: Hatred, Death, and Misfortune


# The Forsaken

1) The Healer - Mercy, Protection and Truth 
2) The Crone: Secrets, Truth and Misfortune  
3) The Fool: Fortune, Misfortune and Truth 
4) The Marauder: Violence, Conflict, and Secrets 
5) The Knight - Justice, Protection, and Mercy 
6) The Hunter: Death, Creation, and Punishment 
7) The Usurper: Greed, Misfortune, and Secrets


# Forgotten Eternals 

The Light Mother: Justice, Mercy, Charity, Love, Light
The Dark Father: Hatred, Greed, Violence, and Tyranny