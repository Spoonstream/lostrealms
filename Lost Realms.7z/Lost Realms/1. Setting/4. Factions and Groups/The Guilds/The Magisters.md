Regulatory and Justice Arm of the Guild Authority. Tasked with the enforcement of violations of guild law in the matters pertaining to arcane or magical restrictions or prohibitions. They are also responsible to oversight of the Order of the Arcane Wizardry, administration of magical aptitude testing and enforcement of criminals that are unregistered magic users of the occult or arcane (although they are not required to validate the spell casters, so they in reality use their power on all kinds of spell casters).



Censors
Monitors
Overseers


 