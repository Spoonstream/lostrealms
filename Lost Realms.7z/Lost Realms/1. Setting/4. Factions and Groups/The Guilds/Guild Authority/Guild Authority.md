Political Body representing collection of guilds within [[The Sovereign Kingdoms]]. They are empowered by international agreement to regulate the use of magic (particularly guild craft), production or goods, and trade for [[The Sovereign Kingdoms]] to ensure adherence to to the agreement. 

They maintain influence due to capital strike and hold great influence over international policy. 

They have (with "oversight") been empowered to hold authority over the reclaimed lands..to ensure the transition and avoid conflict between Sovereign Kingdoms over land disputes. This is done mostly through the the regulation of travel to and from and [[Charter's]].

They hold power over smaller representative guilds through the consolidation of refinement methods and through influence over the use of gateways. 

There are the individual guilds and then there are is the guild authority.