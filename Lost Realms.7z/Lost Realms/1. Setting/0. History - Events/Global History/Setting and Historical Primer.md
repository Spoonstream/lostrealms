#### Enarynn 

The backdrop of stories within this setting are focused on the events on the Continent of Enarynn. There are other continents, places and events in the world of Luminel, but Enarynn unique in 3 ways. 

First, Enarynn was the center of many of the most ancient civilizations. It is believed that the First People made their home upon the continent, after creation. Many of the ancient races, that were created by them are believed to have began there. 

Second, it was the seat of power of every major civilization that has impacted the story elements that are central to the settings storyline. As a consequence Enarynn is riddled with ruins, labyrinthian complexes, dungeons, and "lost" cities. It has attracted many looking for answers for esoteric questions, lost histories, and ancient arcane knowledge. 

Third and finally, most of the continent has been cut off from the rest of the world for the last 150 years by the Boundary. This has effectively led to the regions, diverging, both in culture, but also development. Until very recently travel and communication across the Boundary has been extremely limited. Re-established gateway's leading in and out, have sparked a gold rush and new era of conflict as the New world clashes with the Old. 

#### The Boundary

The Boundary is a magical created wall that encircles most of the Enarynn, cutting it off from the rest of the world. Travel across over and underneath the Boundary is impossible, as is teleportation without the use of a gateway. There are some places, where gaps or routes exist for short periods of time. Those routes are usually kept very secret or have not been discovered or fiercely guarded by those with the capability of doing so. 

The Boundary was built over a millennia ago, by, Thaelos Fate-Changer, the most powerful magus the world has recorded to have seen. After creating an empire that spanned the entire world and would endured for 1000 years, Thaelos built the Boundary, then disappeared (presumably they had been killed).

For over the span of ages that followed the Boundary laid dormant, inactive, the rest of the world either ignorant to it's construction, or assuming Thaelos's mysterious final project, had never been finished. That changed 150 years ago, when abruptly during a conflict that had begun to threaten peace over the world, the Boundary became active. When by intention, plan, or by whom is unknown. 

The result was the severing of contact with the build of the grand continent, that had been the center of civilization since the Age of Myth and Wonder. The Gateway's to and from the interior were likewise rendered inactive and remain that way until one was reestablished no 20 years ago. 

With that gateways activation and new age has been called on. The Age of Reclamation, as the new modern world begins, to colonize and conquer the realms beyond. 

#### Gateways

Most transportation is done using a teleportation circle system, known as gateway's. Gateway's were first erected during the early imperial expansion over a millennia ago. They have been maintained and operated since that time, and span the globe. The gatekeeps, fortifications that were built to defend and protect the gateway's themselves, sit at virtually every major city on Luminel.

While travel by road or sea still is used, it is rare for any kingdom or state, to build let alone maintain more than one or two, for the purpose of trade. This leaves most rural travel, relegated to common paths or communally maintained (and hence poorly constructed) road systems). Sea travel as a consequence still frequently used, albeit to transport cargo to large for a gateway, or to and from area's that do not have them (because they are not large enough to justify their construction). 

Paradoxically, the ability to create a gateway is a well guarded secret, still held by the Order of the Arcane, despite the Order being weak politically. It is largely due to this fact that magic use, outside of the guilds, is tolerated at all. Without the Order of the Arcane, travel and trade would collapse, virtually overnight. 

Enarynn itself, has limited gateway routes, across the Boundary. The only active one currently being to famous ancient city of Mekh'Reban, called the City of Many Splendor's, and the Last Watch keep, in the mouth of Traitor's Bay to the west across the ocean from Enarynn. This gateway has been reactivated very recently (20 year's ago), at great expense, by the Sovereign kingdom's. It is summarized that this difficulty, in reestablishing the gateways, was by design. 

#### The Conclave, The Sovereign Council.

Not having their right's as ordained by the Eternal's to rule over the land recognized, the petty fiefdoms, gathered together and formed the Conclave. A council or allied kingdom's, backed by the economic and political might of the Guild's, and confirmed by the newly formed Church of Faith Eternal. 

This sparked a war that lasted over 200 years and ended with Boundary separating Enarynn, from the rest of the world. The Conclave continued to rule and solidify it's powers, collectively the many kingdoms and States, collectively calling themselves the Sovereign Kingdoms. Reinforced through a stable and structured system of trade and economy, and consistent in it's enforcement of "international law" and right's, this system has led to the development of a society, that the world has not seen since at very least the empire. 

Through the Conclave, the transfer of power is regulated in each kingdom, laws against the Order of the Arcane are upheld throughout the entirety of the Sovereign Kingdoms, and all of it's members have experience economic growth and prosperity. 

Not all within have benefited from this new regime. As it favors those who have the power, those who do not are often subjected to the whims of their betters. While certain "rights" are taken as inalienable, others are seen as privilege's and can be taken away, usually by those with the former.  

#### The Guilds




#### The Order of the Arcane



#### The Eternals, The Forsaken and the Church of Perennial Worship.





## A (Not so brief) History 
#### All endings must have a beginning.

It began with the first horizon. Light meeting Darkness, in a formless expanse of void and energy. The Aetherium, a place of pure creation and negation, energies that pool, collide and spark. Within those eddies, a primordial thought emerged, "I am". Simultaneously bursting into existence creation and destructively separating itself from everything else. The thought yearned for more, like a hungry fire, it consumed and transformed. It grew and from it emerged the *En'nui'al*, the First people. 

Awakening and consumed with a fever of impulse and vigor of youth, they began to create. Wrapped up in a frenzy of creating and destroying, the acted with wild and reckless abandoned. The tumultuous activity carried on without any measure of time, until in their frenzy they created it. One moment, they first moment, was a creation of the same measure. For they not only imagined themselves and had conceived of everything else, but became aware of the differences. They were wrought with anguish and despair, looking around at the formless playground of ideas given shape, form or feeling, they dismayed at the ruin and chaos they had created. 

They began to build a home for their creations. That home became the world of *Lum'rin'el*, "Home and Birthplace", shortened in the modern era to be Luminel. Placing their creations upon it, the ancient beings came into existence. Thus the end of the Discordance came to an end. 

Nothing is known for certain about the Discordance. Only the most ancient beings, if they still exist on Luminel at all, would have any experience with this time. Most of telling's of this of this time of myth follow the same pattern, although there are many variations of the tale. There is nothing certain about this time, even magical means have failed. To most it is just a story. 

#### An Age of Wonders and Ruin (Unrecorded history. -20,000 to -5000 )

While still cloaked in myth and vague metaphor, there is more information about what came after. The First Age, was an entire age of wonders. The *En'nui'el*, existed in this time, coming down to rest with their offspring, the first ancient beings. The place they resided in, was the continent of Enarynn. 

Tales or accounts that were taken later, tell us that this was a time, when  Luminel drifted on the sea of the Aetherium.  The world was ruled by the First People, and their children, who had inherited immense power from their creators. The many children and their divine caretaker's could create and destroy with ease. They wield awesome power and made many things. 

Their were many events during this time that have been lost to time or forgotten. Two events will always remain in the memory of people. The Divine War and the Sundering. While depictions of these events may differ there are five details, that arises in every version of these events. 

First, that beings who later would be called The Eternals, were mortal, although it's unclear of which ancestry (ancient, modern, or otherwise) they belonged to. 

Second, for some reason, they turned against the The First People.

Third, that rebellion, began the catastrophic Divine War. How long the war lasted but the scope was larger than any war ever since fought. 

Fourth, the Eternals, stole immense power, that elevated them above every other ancient and quite possible above even the First People. Know one can agree from who, or how they stole this power, but all versions agree that they took it from someone or something. 

Finally, the Eternals were responsible for sundering the Luminel from the Aetherium. A division that resulted in an apocalyptic calamity, ripping apart, trapping or destroying every being in connection to it, and forever separating the world from the creative energies, of which gave it birth. 

No one knows, the fate of the *En'nui'el*, although many accounts from oracles, diviners, and priests would suggest that they lived. Many versions of the tale, see them being forever separated from their muse, the world of Luminel. 

The Eternals, however are known to exist within whatever lies in the Aetherium or beyond. They alone have the ability to penetrate the barrier that separates worlds, whether to communicate or bestow a measure of their power. There are even historical accounts of them taking mortal vessels and returning for short periods of time. The some Eternals have taken up the roles of deities, to watch over the realms. Is why they sundered the realms? Again there is nothing for certain.  

The consequences that of the Sundering, was a calamity that left the world in ruin. In its wake a new era had been born.

#### The Long Shadow (-4999 AWC to -321 AWC)

With the sundering, entire civilizations were wiped out or reduced to scattered groups of survivors. For hundreds of years the people of Luminel, existed in a terrified fugue, as they attempted to rebuild, and survive.

Knowledge was replaced with intense paranoia, superstition and fear. Without the connection to the Aetherium, the power that society's had become dependent on was gone. People turned to developing the ability to plant, cut, burn, and build through physical labor. They were forced to create primitive tools that and weapons to survive and protect themselves.

Life existed this way for four thousand years, as new civilizations rose and then fell, leaving civilizations in their wake. The world struggled, each in isolation and fear, as the many of ancient one's and denizens not native to Luminel had been trapped behind the Sundering Veil. Some of the ancient one's disappeared, believed to have been destroyed or to where is unknown. Others were transformed, physically changed or went mad. Many turned their attention and sought to terrorize or conquer others. 

It was out of this dark time, that faith's, cult's, secretive groups seeking access to ancient powers or the patronage of ancient being's sprang up. These endeavor's only heightened superstition and caused much violence out of ignorance and blind religious zealotry. The faith in the Eternals came into being, offering protection and real power. These faiths often didn't see to rule as much as to convert and acquire followers. They would often support, rather than conquer. The Eternal's religion helped with the longevity and security of the many monarch's during this time. Through support the rights of royal bloodlines, securing the inheritance, and even defense during war. It created a badly needed political stability.

With that stability, new sources of education and knowledge arose. This attracted those searching for access to the Aetherium. The first organized order's devoted to the study of arcane knowledge came into being. Collectively they still exist today, although their power would rise only to be brought crashing down. 

#### A Beacon of Hope, Foundations of War. (-320 AWC to 1000 EIC)

Little is known about Thaelos Fate-Changer, before he came to power. He was unknown wizard, who was a member of the First Order of the Arcane, which was prestigious because of its pedigree, but overall not very influential, powerful or large.  However, within a very short amount of time, of being appointed Grand Magus, he would change, Enarryn and the rest of Luminel. 

Mysteriously acquiring arcane powers, more powerful than anyone had ever seen, he consolidated the disparate schools and Orders of the Arcane and began overthrowing the still fractured and feuding kingdoms. Members of the many faiths were also likewise, defeated, beaten or destroyed outright. Taking over the many governments he politically reorganized all of them, separating militia's and warriors from their homeland and unifying them into one consolidated professional military.

The conquest grew, spreading from Enarynn to the other continents, within the span of two decades, the world was dramatically different. Eliminating heads of monarchies, he establish a Autocratic Magocracy. Named using the first language, the Thae're'al (thha - ray -awl) empire, put the practitioners of magic in appointment over the affairs over territories. They directly  answered to Thaelos. Nobles and monarch dynasties reduced to mere land lords, who had to appeal for favor. 

All affairs were directed from newly constructed capital, Merandras. Built on top of what was once a home of the ancients and First People, and located in the heart of Enarynn. From his city, the wizard emperor Thaelos controlled the affairs of the entire population of Luminel. 

Despite his being an all powerful autocrat, that had ruthlessly conquered the entire world, Thaelos ushered in an era of enlightenment, equity, and prosperity. For the first five hundred years of the empires life, Thaelos established education, built the first roads (which still stand), then directed the first gateways were establish, a complex but efficient network of teleportation circles. He established laws of equality and justice, promoted fair trade and labor practices, which increased financial prosperity. He established imperial orders that were tasked with assisting citizen's with general health, safety and community concern's. Finally he outlawed slavery and abolished religious practices that promoted violence against others.

The wizards council, a congress established shorty after building the capital, handled all of the day to day affairs, of which he would or could veto. Thaelos was deeply involved for many of his long elven years, but as time went by he became more and more absent, and relegating, rather than ruling. He became preoccupied and deeply concerned for reasons he would not speak of. 

In the last years of his rulership, one of his last acts, was to create the Boundary, a magical barrier that could be erected in defense of the invasion. He also rerouted the gateways to all funnel through Mahkbet, the largest and most well defended port.

Once finished, as abruptly as he had seized power, he promptly disappeared. What happened is still a mystery, but most scholars agree, that the most likely scenario was that he was assassinated or killed, presumably by members of the council who had conspired against him. 

The empire would continue for 500 years after his disappearance. Slowly but surely corruption, political infighting, nepotism, and greed would creep in. The council would tighten down on their authority incrementally over time, foster more resentment and distrust, as the years marched on. Slowly but surely the empire came to a collapse and when it did, a century of war engulfed Luminel, and would leave Enarynn in ruin.

#### Warlock Wars (976 to 1200)



#### Sovereign Kingdoms and Sacred Land (1200 to 2000)


#### Reclaiming what was lost. (2000 - 2060)


#### Winds Change on a Dark Horizon