City of Wonders

Gateway access to the interior of the boundary.

Under control of the Guild Authority by under the direction of the Soveriegn Conclave.

"gold rush town"

Abandoned section/building ruined part of the city. It is cordoned off by the [[The Magisters]]  no one knows why. 

City is bordered by enclaves sorted by dominant ethnic heritage. The city is ordered by an apartheid system, instituted to prevent decendants claiming reclaiming territory. The propaganda is that cultural movements from within the ethnic groups represent a vocal intent to destablize the soveriegn conclave and the kingdoms.  