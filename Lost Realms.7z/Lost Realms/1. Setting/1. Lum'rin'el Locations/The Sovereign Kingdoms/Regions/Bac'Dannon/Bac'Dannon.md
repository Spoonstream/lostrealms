


Annexed from the Kingdom of  Mal'Kyrnnis (Bad Kings in older language)


### Culture
Greeting
Trigger Custom
Values
Visual Cultural Cue's


Bonds
Vows
Stories