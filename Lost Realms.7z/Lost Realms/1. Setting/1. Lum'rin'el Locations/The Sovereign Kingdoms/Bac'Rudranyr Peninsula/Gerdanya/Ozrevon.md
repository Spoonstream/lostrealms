
Originally named Ozres'stravonia (meaning Place for the orphaned people in older tongue.)


Duchess Con'dannon Elena Kostrová

