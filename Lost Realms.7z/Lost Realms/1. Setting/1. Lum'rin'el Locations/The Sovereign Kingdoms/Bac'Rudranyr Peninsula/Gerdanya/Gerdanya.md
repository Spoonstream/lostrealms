
Capital City: Dum'Dolan (Dum'Duluigane)
	Port City
	Population: 1 Million





### Culture
Greeting
	Fist held to breast
	Greating "con'ya"
	Response  "sur'yan"
Trigger Custom
	Refer to lineage descended from ancestor and deed they are famous for.
Values
	Family Reputation
	Strength
	Victory
	Hierarchy and Station.
Visual Cultural Cue's
	Embroidered clothing denoting family and station. 


Bonds
Vows
Stories



### History Notable Events