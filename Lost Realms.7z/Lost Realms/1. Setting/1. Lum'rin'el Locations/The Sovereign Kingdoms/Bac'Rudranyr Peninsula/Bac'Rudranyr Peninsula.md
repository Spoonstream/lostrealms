
Western Peninsula

[[1. Setting/1. Lum'rin'el Locations/The Sovereign Kingdoms/Bac'Rudranyr Peninsula/Gerdanya/Gerdanya/Gerdanya|Gerdanya]]
[[Rochaine]] 








