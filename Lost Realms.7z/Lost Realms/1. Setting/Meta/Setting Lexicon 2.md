Date: 2.10.2024

## A

**Al'Ralni (Language)**

: Language of the "First People" spoken since before recorded history. While it has undoubtably changed over the millenia, the language is still in use by those of elvish descent, some scholars, and by [[The Perennial Faith]] in some of their oldest rights. 

**Age of Anathema (Historical Period)**

: Time period spanning from 2898 IC to 3990 IC. The onset of this age begins with a plague that spreading from a famine. This age was marked with disease, fear, societal unrest, and wars. Towards the end of this age, necromancy and the undead first appear which begins global conflict as cult insurgencies, coups, and wars engulf the world. The age ends abrubtly with activation of [[The Boundary]], over Enarynn and the disruption to the Gateways system.

**Age of Creation (Mythological Period)** 

: Mythological time period believed to exist before the Discordance and recorded history. It is unknown how long or when this period existed. This is when Lum'rin'el, the natural world, as well as the ancient beings that inhabited that time were created. Most myths attributes creation to two "beings" Nui and El, mythological metaphors for darkness and light.

**Age of the Empire/Imperial Age (Time Period)**
: Time period associated with the calendar record spanning from 0 IC to 1460 IC. The calendar estimates the appearance of Thaelos Fate-Changer, the first arcane magic user. With the power of magic, he builds the Thaelon Empire which spans the globe. The Imperial Age is a time where civilization is ruled by Magocracy, and arcane magic see's widespread practice. During this age, religious practices and those claiming divine rights, given to them from [[The Eternals]] are actively suppressed.

The first half of this age are regarded as a time of great progress and innovation, while the latter half are remembered as a time of corruption and tyranny from corrupt arcane councilors. With open declaration of revolt the age comes to an end. 

**Age of the Long Night(s) (Time Period)**

: The age prior to the Imperial Age or record. Spans from -5000 BIC to 0 IC. Very little is known about this age, it is known as a time of ruin and upheaval towards it's beginning as the Sundering left the world in ruins. Dominated by many wars between small kingdoms and nations that existed during this time. 
:Many cultures and civilizations, disspossessed because of [[The Sundering]], merged during this time. Somewhere towards the middle human begin to appear, a product of ancestries intermixing.

**Age of Reclamation (Time Period)**

: Time period spanning from 3990 IC to the year 4184. Formally called the Age of Division, the name was changed 10 years prior to the current date 4189, to the Age of Reclamation, when gateway accessing the lands beyond the boundary were opened up again, a group of adventures. These adventurers somehow managed to traverse the Boundary, and reactivated the gates.  

**Age of Reformation**

: Spanning from 1460 IC to 2898 IC

**Age of Wonder**

: 

**[[Aetherium]], The:**

: 

## B

**[[Bac'Dannon]] **

:

**[[Bac'Rudranyr Peninsula]] **

:

**Boundary, The**

:

## C

**Calender (Imperial)**

: The date standard used in the modern era. The calendar has 365 days, 7 days a week. Year 0 is a rough estimate of when Thaelos Fate-Changer appeared. Years after that are count IC, years prior to that are BIC (Before Imperial Calander). The current year of record is 5189. 

**Can'lyr (Language)**

: Language native to the nation of [[Gerdanya]]. 

**Camarynn (Continent)**

: A continent located in the North Western Hemisphere. Largely frontier. It is still occupied by tribal communities and small independent villages. There are no Sovereign Kingdoms on this contented. It is mostly rocky mountains, fjords, marshlands and dense wilderness, which makes settlement difficult. The wildlife and natural predators make life very inhospitable. 

**Charter Companies (Organization).**

: 

**Conscilium, The**

: *See Guild: Conscilium, The; The Consulate:*

**Consortium, The** 

: *See Guild: Guild Consortium.*


## D

**Dragons (Mythological Creature)** 

: 

**Discordance, The** 

:

## E 


**En'nui'al (pronounced {EN-WEE'AWL}) (Myth)**

: 

**Enarynn (Continent)**

: 

**Eternals, The** 

: 

## F

Falkdan (Government/Region)

: 

## G

[[Gateways]] 

:

Gazyaven (Language)

:

Gerdanya (Government/Region)

:

Guild: Conscilium, The; The Consulate (Political Organization)

: 

Guild: [[Guild Authority]] (Political Organization)

:

**Guild: Guild Consortium**

:

Guild: Guild Magistrate 

:

Guild Craft (Magic): 

:

Guild Speak (Language): 

:

## H

**[[Hearthstones]] **

:

**High Speech (Language)** 

:

## L

[[Loci]] 

:

Lum'rin'el

:

## M 

Magisters, The; Magistrate (Political Organization): See Guild: Guild Magistrate 

:

[[Mal'Kryinnis]] (Region/Historical Government/Empire/People):

:

Magic: [[Arcane Magic]] 

:

Magic: [[Divine Magic]] 

:

Magic: [[Occult Magic]] 

:

Magic: [[Primal Magic]] 

:

[[Mekh'Reban]] (City/Location)

:

## N

Nerynn: (second continent)

: 

[[Nequillan (another orcish)|Nequillan]] (Language): 

: 

## O

[[Ozrevon]] 

: 

## P

Perinnial Faith, The. (Institution/Political Organization)

: 

## R

Reclaimed Territories (Region)

: 

[[Rochaine]] 

: 

## S

Sakhran (Language)

: 

Sovereign: Conclave of (Political Organization)

: 

Sovereign: The Sovereign Council (Political Organization)

: 

Sovereign: Kingdoms (Government)

: 

Sovereign: Southern Sovereign (Political Alliance)

: 

Sundering: [[The Sundering]]  

: 

## T

Thaelon Empire 

: 

Thaelos Fate-Changer

: 

Turynn: (Third Continent)

: 


## W

Warlock Wars, The 

:
