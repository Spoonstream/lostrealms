
**Concept:** Jumping off point for worldbuilding the Last Watch campaign setting. The idea is to provide enough world building for general world overview, character creation, and to get a campaign started. 


### Variant Rules (that I want to use):

- Proficiency without level bonus 
	- This might require some experience with the PF2E system and better breakdowns of challenge rating. 
	- The reason why I want to use this is because any campaign setting i run, should be more or less indifferent to the characters level AND I prefer bounded accuracy. "Boss Fights" should be accompanied by shit loads of lesser minions. 
- High Quality gear
	- I want to expand upon this rules set very much.
- Deep Backgrounds
	- Although I might not use this on the first run. I want to eventually use this or my own spin on it. The eventual campaign setting rules set will have a similar approach and using this will make it much easier to transition.
	- I just plain like lifepaths...nuff said. 

### Homebrew systems
- ##### Charters
	- More of a test run of the concept. 
	- Provide the questions and answers. Each answer can affect the game mechanically (during character creation etc.). The amount of choice here is less important than just seeing how this works when people know that it impacts the mechanics.
	- The entire exercise is so that the group's morality is determined and story situations. 
- #### Minutes to Midnight
- #### Expanded Variant on High Level Gear Qualities. 
	- an "externality" system for normal magic items
		- Needs to provide a pressure system (feeds into minutes by midnight?)
		- Creates a ethical consequence to using magical items. (I want players to feel bad about using magic items the way I feel about using cellphones).
		- This should be a narrative device in the first campaign just to make the characters themselves question it.
	- My version of covenant items from midnight.
		- I want magic to feel special but also not be crazy rare (because I am the only person that enjoys that apparently.)
		- They grow in power as you level.
		- You change as they change. 
		- They are less utilitarian but more powerful in many regards
	- Special Materials that are tied to the themes of climate change.
		- Precious items that have innate "magic like" qualities.
		- They are tied to a region where they are harvested. This is usually involves systematic destruction through the process of neo-liberal accumulation. 
- #### Homebrewed Magic Schools.
	- I want a distinct difference between the esoteric nature of magic and the ordered material based systems that have sprung up around the use of magic. 
- #### Races/Heritages/Ancestry Rules
	- Need something that is balanced with the system but reflects the actual nature of my world. The racial options are very much a non-starter for me.
	- **Rework the order.** Characters should receive the same numerical benefits and access to ancestry feats. It's a intentional mechanics choice to reflect on how race is used in fantasy and break players from that idea.
	- **Idea:** Perhaps just condensing the choices into a few specific races that all ancestries are decedents from and get to choose 1 flaw attribute and gain a boost in another attribute of choice. Depending on what you choose you - may have access for an Ancestry.
		- The 3 root Lineages are;
			- Humans - Dwarfs, Goblins, Gnomes (near extinct), Halflings, Orcs, Dhampirs.
			- "Animal Spirit People" - Cat folk, Rat Folk, Tengu, 
			- "Planer People" - Changeling, Aasimar, Dusk Walker, Teifling, 

### Premise
The first leg of the campaign is a border crossing. It is broken down into 5 segments. Each segment is 2-3 sessions. 
- **The Package:**
- **The Border:**
- **The Crossing:**
- **The Tomb:**
- **The Destination:**






