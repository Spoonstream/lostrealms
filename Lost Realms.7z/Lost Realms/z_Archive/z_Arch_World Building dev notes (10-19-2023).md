
Thematic Concept: 
	It's not about saving the world. It's about holding on to hope.
	It's not about saving the innocent, its about searching for innocence.
	It's not about defeating the enemy, it's about conquering your fear.

3 Core Design Philosophy's
	1)Action Matters, Story Matters More
			The characters will want to do things. Those "things" should always serve the immediate narrative (fiction first mechanics) but also serve to build upon their own personal Narrative
	2) Make the players invest in the consequences and then raise the stakes.
	3) Many choices in wrapped up in a simple sets of rules. 


Game Synopsis

Players take on the role of characters adventuring in the dangerous and ancient  continent of Enarryn. Once the birthplace of civilization millennia have marked the ruined continent. It is a land on the fringes, under constant siege of the colonial forces of the Guild, old orders and conspiracies' that seek vengeance for past wrongs, rebellions and revolutionaries, adventures seeking fame and fortune, criminals exploring the weak and vulnerable, and those lost souls seeking truth at the ends of the map. 

Underneath all of that is the looming dread of a dreaded fate. What distinguishes the characters in this story from any other inhabitant of this world, is that they sense an the coming of a storm, or a calamity. They don't know how long, what will happen, or what the consequences will be. 


REVISE ABOVE...THE ETERNALS ARE DARK GODS THAT PRESIDE OVER THE GUILD AND ARE CAUSING CLIMATE CHANGE....


Unique Mechanics and Features

1)  The Calamity Clock
	1) Each character has a progenerated (random?) fate that will be given to them. This is the "sign" that they were born under - and serves to give the player a hint of some upcoming event. Collectively all of the characters fate signs will help the GM with the event.
	2) During the game the clock will be present for all players to see and will count down. The amount that the clock. The scale of the event and the time until its occurrence is determined by the players. 
2) 3 Difference types of player currencies
	1) Personal Points - used to fuel personal abilities that are offensive or allow the player to do things without increasing GM Plot Dice.
	2) Team Points: Used to provide dice pool bonuses, power body gaurd effects - these can also provide a personal benefit when given. 
	3)  Defensive Points - Allow the player to resist or reduce the consequences of GM outcomes
3) 3 Character advancement paths
	1) Drives
	2) Touchstones
	3) Background (needs a better term)


Game Loop:
Need's inform motivation, motivation informs choice, choices inform consequences, consequences inform new sets of the needs. 




