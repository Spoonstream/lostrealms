###### *Notes 12/4/23 - needs to be completed and revised*

## Forward

Someone once told me, "no matter what you end up doing in life, it should involve telling stories...it's your gift." That really stuck with me. Every now and then I would remember that and think to myself, "man that was really good advice...I should do that." The only problem is that, when acting on it, I would always end up going in a direction that feeling as though I had come back full circle. Sure I would learn things along the way, and I always had a good time (mostly), but eventually I would become aware that time had passed, and an uneasy feeling that I, "wasn't there yet", would come creeping back in. Looking back on those times, I now realize, that despite everything else, all the unease and frustration, I had been moving forward, just not in quite the way I expected. 

Now this is a weird omission to put at the beginning of this document. I recognize that. I wander with my thoughts, every now and then, letting my thoughts out to exercise, turns them into great ideas. I wanted you to know where I am coming from, and why I put as much effort, into what other people would just see as your run of the mill rpg game. It isn't quite run of the mill for me though, there is allot going on though in the back-end my brain. It's all those pesky thoughts wanting to go jogging.

I want to run a game, that is simple on the surface, and that really, is the only thing important. Fixating on that though, has really started working those thoughts out. It's not bigger than it should be, but I feel a good sense of momentum. It's the kind of thing that I really love to do. There is a good vibe, and that's why I am going overboard like this. It's all those crazy idea's, just needing to throw a collage house, get pumped up on coke and steal a cop car or two. 

The big difference though behind this energy and those other times, is that I think that the person who gave me that advice was slightly wrong. My gift isn't telling stories, my gift is (and always has been) your stories.

Enjoying them just happens to be an obsession of mine. 

## This is NOT a test

I am testing some proof of concept mechanics for this campaign. The intention is to observe how you engage with elements of the story, and specifically two mechanics. The end result may or may not be in pathfinder or even in the product I am designing. Keep in mind that this is not a test, I am just merely observing how certain ideas interact in a game environment. Telling you more details might skew those observations and would honestly put more focus on this that even I want. 
All I ask are 3 things 
	1) Engage with the game normally 
	2) Engage with charter and storyboard system and give them a chance 
	3) Reserve input for outside of session. If it is a burning great idea say that you have one...and I will come back to it after the session. 


## "Doug's gone overboard again"

Is this to much? Yeah probably. But I want to put together the necessary information in one place. It should help facilitate character creation and keep all of the rules (Homebrewed) more consistent, as well as allow me to more comfortably express unique concepts and situations in the narrative. 

Things are easier when everyone is on the same page.

I have organized this for the sake of sanity into the following sections
1)
2)
3)


## Game Information

#### **Time:** 
TBD (It's looking like Sunday's during the day ATM). How often is also something that is TBD. Right now I am shooting for having the first session in January sometime. 

#### **Game System:** 
Pathfinder 2nd edition Remastered. Player Core 1 and GM Core 1
#### **Why Pathfinder?:** 
The short answer is the easiest thing to get a game up and running, and the closest rules system that I would be willing to run. 
#### **Setting:** 
Lost Realms (Custom Setting)
#### **Genre:** 
Fantasy - This setting borrows in different ways from different sub-genre's of fantasy. Below are some of the genre's and in what way the setting uses them.
- **Swords and Sorcery**
	- **Agency** 
	- **Scale and Moral Ambiquity**
	- **Cosmic Supernatural Forces:** 
- **High Fantasy**
	- **World is Internally Consistant:**
	- **Magic is ubiquitious (sort of):**
- **Low Fantasy**
	- **Realistic Society (Sort of):**
	- **Medieval level of Technology:**
- **Dark Fantasy**
	- **The Unknown and Esoteric:**
	- **Dark or Horrific Nature of Fantasy Elements:**
- **GrimDark**
	- **Corruption and Immorality:**
	- **Oppressive systemic social forces:**

#### Common Setting Themes

#### Ideas have power.
These are stories woven in the tapestry of ideas. Oath, charters, tenant's, sigils, and contracts. It is bound up by these things, they enforce and make up reality itself. 

#### There are always consequences
They are always felt by someone, rarely fully recognized by those who cause them, and can often happen in unexpected ways. 

#### F.




#### **Length:** 
At the moment I have outlined, 5 chapters of about 2-3 (4-5 hour) sessions per chapter. that could last for 10-15 session total. At every other week that would make about 6-7 months of gameplay. 

#### **Character Creation Guidelines:**
- I am going to be testing a mechanic that I am calling the "Charter Creation System." This is described in more detail below. 
- We will be creating characters during session zero 
- DO NOT CREATE YOUR CHARACTER BEFORE THE FIRST SESSION
- If you are chomping at the bit, come to the table with 3 concept ideas. Character Creation is going to be very focused on constructing the group together, having different options that you are happy with would help that...but is not mandatory.
- All Ancestries, except Leshy's (Mushroom/Plant people), in the player core or remastered content is allowed. 
- All Classes in the player core or remastered content are allowed. 
- All archetypes available in the player core or remastered content are allowed.
- If you want something from another book or weird it will more than likely have to be "reskinned" but I am hesitant since it's my first run. Leshy's will be getting a reskin eventually to be more appropriate to the genre.

#### **Character Concepts**
Some of this I plan to have handles with my Charter mechanic. However here are some points to help you get a rough idea ahead of time.
- Characters will all be from the Sovereign Kingdoms or the other continents. I have not written anything down other than some broad concepts intentionally for this reason. 
- The campaign will eventually lead towards crossing the Boundary. When that happens and how that happens will largely be dependent on your choices.
- All of your characters will be a newly formed company under a Charter. The choice of what type and the purpose of that Charter will be.


## Campaign Rules and Special Mechanics

### General

#### **Relevant Rulebooks:** 
- We will be using the Pathfinder Remaster Rules Player Core 1 and Game Mastery guide. 
- The Rules are free and available online. You can find links to the rules below with the other online resources
- Online Resources
	- Archives of Nethys -  https://2e.aonprd.com/. 
	- Pathfinder Nexus - https://app.demiplane.com/nexus/pathfinder2e

#### **Rules use during game:** 
-  We are going to get shit wrong....allot...don't be a dick.
- During game session, I will place priority with game flow and narrative; over spending time referencing or following procedure read as written (RAW).
- After every game, between sessions, I will be looking up every rule that was used, if you want a rules discussion then save it for that time. 


### Setting Specific Adjustments

####  Teleportation, Dimensional/Planer Travel, and Summoning: 
The above abilities function differently in this setting. I will be using the following guidelines when determining the availability, usability, and effects of powers that:
1) Teleport any person or object from one place to another.
2) Open a gateway or use dimensional effects to travel or manipulate the real world. 
3) Any power, ability or effect that gains access to other planes of existence or creates pocket dimensions within existence.
4) Any effect that that summons a person, creature or object (animate or inanimate) from one location (or plane) to another. 

##### **Guidelines concerning Teleportation and Dimensional/Planer Travel:**
- Teleportation of any kind across the Boundary (in either direction), is impossible unless conducted via Teleportation Circle. 
- The creation and operation of teleportation circles is a closely guarded secret and hence not available to player characters. Operating a teleportation circle requires a special amulet that has been specifically attuned to a specific individual. Once attuned the amulet will never be able to function for any other individual. 
- Furthermore Teleportation Circles can only be created and operated in very specific places (known only to the Guild of the Travelers), and hence require those places as a requirement for their creation. 
- Travel to other planes of existence is not possible. Any ability that creates or allows for the effect of planer travel, does not exist and is not available to the characters. 
- Portals, Gateways or effects that use Dimensional travel cannot be used to travel or transport anything across the Boundary. 
- Pocket Dimensions or Effects that involve the use of dimensional effects either don't work or function differently. These may be restricted or altered on individual bases.
- Effects that summon anything cannot be used across the Boundary.
- Effects that summon anything, always transport that thing from another random place within the plane itself. This is always at random, and in place of where the target of the summons was, a magical aura signature of the caster exists. This can be used to identify, locate or scry on the caster of the summons. Once the duration of the effect comes to an end the aura disappears. Please note that there are many otherworldly and extraplanar beings that exist on the material plane but in order to use abilities or effects, to summon them, the being must be on the material plane. 

####  Shapeshifting and Wild shape power's:
- Any power or ability to used to shapeshift into a animal or creature usually must have communed with spirit of that animal to ask permission of that the spirit of that creature (not the specific creature's spirit). This is done via simple ritual. Those that attempt to use effects without being granted permission, may experience...side effects...

####  Plant Growth Ritual. 
- Use or knowledge of this ritual outside of authorized members with the Guild of Bounty, is prohibited. This ritual may not be obtained at character creation and is only accessible through very specific means. 

#### **Raising the Dead:**
- Can have...side effects. 
- Can also spontaneously happen sometimes. Many cultures either consecrate, entomb, or burn their dead. It is a very known and common thing, and dead bodies are always treated with caution until measures have been taken to insure that they don't come back (typically until a priest of cleric says so). 

#### Runes
- Sigil Runes

###  Rules Variants and Homebrew Rules.

##### Proficiency without Level Variant Rule
- I will be using this rule. Neither Characters or NPC's, will a profiency bonus conferred by their level. 
- This will mean that "encounters" and NPC's are not always scaled to your level. It also means that lower level "encounters" can still be a threat. 
- Difficulty Challenge numbers DC's are adjusted to compensate.

- For Simple DC's the target number will be the following:
	- Untrained 
	- Trained 14
	- Expert 18
	- Master 22
	- Legendary 26
- For Treating wounds the DC's have been adjusted to the following
	- Untrained: - 
	- Trained: 12
	- Expert: 16
	- Master: 18
	- Legendary: 22
- For DC's by level, the DC is 14 + (level/3 round down.), for levels 0 and above.
	- For level -1 the DC is 13.

#### High Quality Gear Rule

Magic Items have a unique role, as opposed to many other fantasy settings. Magical Items are fairly common but they are also not common. There are three types of magical items 
	1) **Guild Crafted** - This applies to basically magical items, as you normally find them, from the rulebook (including Sigils)
	2) **Special Materials** - There are many special materials that have magic effects but are not themselves the product of magical enchantment. There are many ways to identify these materials and their properties. This *may* include, but is not limited to, Arcana, Occultism, Craft, and Lore. 
	3) **Relics** - Within this setting relics are distinctly different from normal magical items and identifiable as distinctly different. There is one particular aspect of Relics is known as "Sovereign Relics", which where inherited items from the Age of the Eternals. They are rare and for the most part lost. Other special aspects for relics also exist (I just haven't created them yet). 

Why the mechanical difference? 
- The type will determine availability and treasure. 
- I will keep track of number of Guild Crafted items carried by players for "reasons".
- I have always felt that magical items are ridiculously common...fantasy settings have slowly led to magical items being literally EVERYWHERE...but the game system and most players assume that magical items will be easier to come by. So yeah this is the compromise.  

**Need to insert custom materials here**

##### Charters
One of the things I am actively testing is the mechanic I am calling "Charters." Charters are composed of three parts. As of the writing of this the system's specific details are still being worked on and refined. To be honest I will probably be working tirelessly bringing myself up to speed and doing math on things all the way up to character creation, so I am covering my butt in this regard. Please refer to the "this is not a test" part at the beginning about why I am doing this before telling me just to wing it or complaining that I am fucking with the balance please.
- The first is a brief session zero OOC it will have...
	- Questions. like time of session, ooc behaviors, type of story elements and banned topics or content. These will be brief, easily fillable, and for the most part should be rather easy. I will be providing either base "assumed" answers, from which we can go over and add or subtract things. 
	- It will tell us, the OOC Game Roles and their alternates (explained above).
- The second part is a sort of group character sheet. 
	- It will have PvP mechanics (chosen from several options), 
	- the group "concept", this will provide what your groups generic purpose, what a driving goal or motivation which will have an XP reward whenever it is accomplished in game. This might also have a mechanical  benefit or options (TBD).
	- Players will pick from a list of options or create 3 tenets which will work as a sort of IC behavior guidelines. These are framed in the positive and my intentions are for them to be more motivating rather than "Morality rules". But they will serve that purpose as well, essentially its an in character narrative element that also serves as a way to agree OOC on what kind of RP you guys are comfortable with or want. Some groups don't mind the other characters habitually stealing from each other, but most groups would end up murdering you in your sleep. 
- The third Part will lead naturally into your own individual character creation. How this works is still being worked on. The intention will be to provide you with a more digestible amount of options, give you some background selections (lifepaths baby) and at the same time give you a concrete way of discerning how your class contributes to the group concept (it might even incentivize specific sub-class or specialties).

##### Storyboard
This as well is forthcoming. I am working on a game system that will hopefully allow you to better keep track or story elements, refresh your memory and provide a framework for GM's to create stories easier. It will involve a (hopefully) fun little game artifact that will visually represent these things. 

##### World Specific Deities
The world doesn't have in the classic sense. It has the Eternals and Forsaken. The difference is that these beings were once mortal creatures that have "Transcended" their mortal vessels and have "godlike" powers. 
They mechanically no different than than the Core Rules, with exception that they have their own edicts and anathema. When choosing a patron or deity, we will be using the setting list  or I will have to work with you, if one hasn't been created yet. 

## Setting Information

#### Common Themes

#### The Accursed Question.
The tides are rising everywhere. Lost Realms isn't as much about finding the world ending dangers, or even saving the world. Stories in this setting are more about the dangers of asking "The Accursed Question (s)". The question's that you are afraid to ask, because you know it will threaten everything you have ever believed. 

#### There are always consequences
They are always felt by someone, rarely fully recognized by those who cause them, and can often happen in unexpected ways. 
#### Ideas have power. (*Add and revise*)
Lost Realm story's are woven in the tapestry of ideas. The shape of these stories Oath, charters, tenant's, sigils, and contracts. It is bound up by these things, they enforce and make up reality itself. 




### The Lost Realms.

It has been 100 years since the Old Realms were lost.

100 years of the separation between the Sovereign Kingdoms, the birthplace of the modern age, The Realms of Enarryn, the continent that cradled every civilization and empire since time began, and the First People created the world. A vast land of fractured kingdoms, vast wilderness, old societies, and ancient ruins. 

Between them the Boundary, the destructive force created from a much older time, when the forces of the arcane and those who wielded it were the first to conquer the world. A magical creation, that once guarded that ancient world order from the outsiders, but laid dormant after the world was ruined in the wake of that orders collapse. 

Dormant until it was awakened, by who or what is not known, bringing the last war to a close. Now the at the time newer power of the guilds has risen, and the world has since changed. The magical crafts they produce, have become indispensable, and the Sovereign Kingdoms and beyond have grown to new heights of prosperity, but at a cost. 

The special resources and commodities required for their continued use are precious and rare. Rare everywhere except Realms of Enarryn. So a new era has begun, the era of exploration, a reclamation, an era that is fueled by the ambitions of groups of induvial aligned by pacts and charters. These Charter Companies, travel from far and wide, penetrating the Boundary through its very few cracks.

They venture into the Lost Realms. 

Many are looking for fortune, conquest, and glory. 

Most will find societies, secrets and dangers that would prefer to stay that way. 

### Notable Features of the Lost Realms Setting.

### Enarynn 

The backdrop of stories within this setting are focused on the events on the Contentent of Enarynn. There are other continents, places and events in the world of Luminel, but Enarynn unique in 3 ways. 

First it was on Enarynn, that the First People had made their home, after creation. While their is almost no physical evidence of this, the accounts given by the Eternals, in the very brief moments when they have communicated with anyone on the subject (let alone anyone at all), have confirmed this. 

Second, it was the seat of power of the Thae're'al Empire and other societies of the ancients. This land is riddled with ruins, labyrinthian complexes, dungeons, and "lost" cities. It has attracted many looking for answers for esoteric questions, lost histories, and ancient arcane knowledge. 

Third and finally, most of the continent has been cut off from the rest of the world for the last 100-150 years by the Boundary. 
### The Boundary

### Gateways

### The Guilds

### The Order of the Arcane

### The Eternals



## A (Not so brief) History 
#### All endings must have a beginning.

It began with the first horizon. Light meeting Darkness, in a formless expanse of void and energy. The Aetherium, a place of pure creation and negation, energies that pool, collide and spark. Within those eddies, a primordial thought emerged, "I am". Simultaneously bursting into existence creation and destructively separating itself from everything else. The thought yearned for more, like a hungry fire, it consumed and transformed. It grew and from it emerged the *En'nui'al*, the First people. 

Awakening and consumed with a fever of impulse and vigor of youth, they began to create. Wrapped up in a frenzy of creating and destroying, the acted with wild and reckless abandoned. The tumultuous activity carried on without any measure of time, until in their frenzy they created it. One moment, they first moment, was a creation of the same measure. For they not only imagined themselves and had conceived of everything else, but became aware of the differences. They were wrought with anguish and despair, looking around at the formless playground of ideas given shape, form or feeling, they dismayed at the ruin and chaos they had created. 

They began to build a home for their creations. That home became the world of *Lum'rin'el*, "Home and Birthplace", shortened in the modern era to be Luminel. Placing their creations upon it, the ancient beings came into existence. Thus the end of the Discordance came to an end. 

Nothing is known for certain about the Discordance. Only the most ancient beings, if they still exist on Luminel at all, would have any experience with this time. Most of telling's of this of this time of myth follow the same pattern, although there are many variations of the tale. There is nothing certain about this time, even magical means have failed. To most it is just a story. 

#### An Age of Wonders and Ruin

While still cloaked in myth and vague metaphor, there is more information about what came after. The First Age, was an entire age of wonders. The *En'nui'el*, existed in this time, coming down to rest with their offspring, the first ancient beings. The place they resided in, was the continent of Enarynn. 

Tales or accounts that were taken later, tell us that this was a time, when  Luminel drifted on the sea of the Aetherium.  The world was ruled by the First People, and their children, who had inherited immense power from their creators. The many children and their divine caretaker's could create and destroy with ease. They wield awesome power and made many things. 

Their were many events during this time that have been lost to time or forgotten. Two events will always remain in the memory of people. The Divine War and the Sundering. While depictions of these events may differ there are five details, that arises in every version of these events. 

First, that beings who later would be called The Eternals, were mortal, although it's unclear of which ancestry (ancient, modern, or otherwise) they belonged to. 

Second, for some reason, they turned against the The First People.

Third, that rebellion, began the catastrophic Divine War. How long the war lasted but the scope was larger than any war ever since fought. 

Fourth, the Eternals, stole immense power, that elevated them above every other ancient and quite possible above even the First People. Know one can agree from who, or how they stole this power, but all versions agree that they took it from someone or something. 

Finally, the Eternals were responsible for sundering the Luminel from the Aetherium. A division that resulted in an apocalyptic calamity, ripping apart, trapping or destroying every being in connection to it, and forever separating the world from the creative energies, of which gave it birth. 

No one knows, the fate of the *En'nui'el*, although many accounts from oracles, diviners, and priests would suggest that they lived. Many versions of the tale, see them being forever separated from their muse, the world of Luminel. 

The Eternals, however are known to exist within whatever lies in the Aetherium or beyond. They alone have the ability to penetrate the barrier that separates worlds, whether to communicate or bestow a measure of their power. There are even historical accounts of them taking mortal vessels and returning for short periods of time. The some Eternals have taken up the roles of deities, to watch over the realms. Is why they sundered the realms? Again there is nothing for certain.  

The consequences that of the Sundering, was a calamity that left the world in ruin. In its wake a new era had been born.

#### The Long Shadow

With the sundering, entire civilizations were wiped out or reduced to scattered groups of survivors. For hundreds of years the people of Luminel, existed in a terrified fugue, as they attempted to rebuild, and survive.

Knowledge was replaced with intense paranoia, superstition and fear. Without the connection to the Aetherium, the power that society's had become dependent on was gone. People turned to developing the ability to plant, cut, burn, and build through physical labor. They were forced to create primitive tools that and weapons to survive and protect themselves.

Life existed this way for four thousand years, as new civilizations rose and then fell, leaving civilizations in their wake. The world struggled, each in isolation and fear, as the many of ancient one's and denizens not native to Luminel had been trapped behind the Sundering Veil. Some of the ancient one's disappeared, believed to have been destroyed or to where is unknown. Others were transformed, physically changed or went mad. Many turned their attention and sought to terrorize or conquer others. 

It was out of this dark time, that faith's, cult's, secretive groups seeking access to ancient powers or the patronage of ancient being's sprang up. These endeavor's only heightened superstition and caused much violence out of ignorance and blind religious zealotry. The faith in the Eternals came into being, offering protection and real power. These faiths often didn't see to rule as much as to convert and acquire followers. They would often support, rather than conquer. The Eternal's religion helped with the longevity and security of the many monarch's during this time. Through support the rights of royal bloodlines, securing the inheritance, and even defense during war. It created a badly needed political stability.

With that stability, new sources of education and knowledge arose. This attracted those searching for access to the Aetherium. The first organized order's devoted to the study of arcane knowledge came into being. Collectively they still exist today, although their power would rise only to be brought crashing down. 

#### A Beacon of Hope, Foundations of War.

Little is known about Thaelos Fate-Changer, before he came to power. He was unknown wizard, who was a member of the First Order of the Arcane, which was prestigious because of its pedigree, but overall not very influential, powerful or large.  However, within a very short amount of time, of being appointed Grand Magus, he would change, Enarryn and the rest of Luminel. 

Mysteriously acquiring arcane powers, more powerful than anyone had ever seen, he consolidated the disparate schools and Orders of the Arcane and began overthrowing the still fractured and feuding kingdoms. Members of the many faiths were also likewise, defeated, beaten or destroyed outright. Taking over the many governments he politically reorganized all of them, separating militia's and warriors from their homeland and unifying them into one consolidated professional military.

The conquest grew, spreading from Enarynn to the other continents, within the span of two decades, the world was dramatically different. Eliminating heads of monarchies, he establish a Autocratic Magocracy. Named using the first language, the Thae're'al (thha - ray -awl) empire, put the practitioners of magic in appointment over the affairs over territories. They directly  answered to Thaelos. Nobles and monarch dynasties reduced to mere land lords, who had to appeal for favor. 

All affairs were directed from newly constructed capital, Merandras. Built on top of what was once a home of the ancients and First People, and located in the heart of Enarynn. From his city, the wizard emperor Thaelos controlled the affairs of the entire population of Luminel. 

Despite his being an all powerful autocrat, that had ruthlessly conquered the entire world, Thaelos ushered in an era of enlightenment, equity, and prosperity. For the first five hundred years of the empires life, Thaelos established education, built the first roads (which still stand), then directed the first gateways were establish, a complex but efficient network of teleportation circles. He established laws of equality and justice, promoted fair trade and labor practices, which increased financial prosperity. He established imperial orders that were tasked with assisting citizen's with general health, safety and community concern's. Finally he outlawed slavery and abolished religious practices that promoted violence against others.

The wizards council, a congress established shorty after building the capital, handled all of the day to day affairs, of which he would or could veto. Thaelos was deeply involved for many of his long elven years, but as time went by he became more and more absent, and relegating, rather than ruling. He became preoccupied and deeply concerned for reasons he would not speak of. 

In the last years of his rulership, one of his last acts, was to create the Boundary, a magical barrier that could be erected in defense of the invasion. He also rerouted the gateways to all funnel through Mahkbet, the largest and most well defended port.

Once finished, as abruptly as he had seized power, he promptly disappeared. What happened is still a mystery, but most scholars agree, that the most likely scenario was that he was assassinated or killed, presumably by members of the council who had conspired against him. 

The empire would continue for 500 years after his disappearance. Slowly but surely corruption, political infighting, nepotism, and greed would creep in. The council would tighten down on their authority incrementally over time, foster more resentment and distrust, as the years marched on. Slowly but surely the empire came to a collapse and when it did, a century of war engulfed Luminel, and would leave Enarynn in ruin.

#### Order against  Arcane.


#### Sovereign Kingdoms and Sacred Land


#### Reclaiming what was lost.


#### Cracks begin to grow.


## Character Information.
All of this pertains to the role and setting information that might set this class apart from other fantasy settings.
- I have left some blank. This is so I can fill it in later or you can add input.
- I am not changing any of the mechanics at this point, however.
- Other Ancestries, Arch types, and Classes will be added later, especially as the realms beyond the boundary are explored.
- All of this information pertains to how these character options narratively function in the Sovereign Kingdoms and other "Civilized lands".
- These distinctions are not global differences, each area of the world can have distinctions and differences.


### Ancestries
Demographically, most people in the civilized world, both the Sovereign Kingdoms, and beyond, are of mixed heritage or express physical characteristic's of other ancestries, instead of the ancestry they were born to. For that reason I have added Mixed Heritage at the top, but in addition to that if you select a ancestry, other than Mixed Heritage, your character may have ancestors that come from other ancestries, but receive the mechanical benefits and flaws of the one you chose. 

I plan on making changes to the ancestries long down the road, but the scope of homebrewing is beyond the scope for this campaign and it would be massive project, involving a ton of work and very careful consideration. I feel, given the timeframe and other priorities, that this will be enough for now.

**Mixed Heritage:**
*(Mixed-Elves are demographically the rarest mixed heritage)*
*(Dwarves, Humans, Medwen, are the most common)**
*(Goblin and Orcs are all equally common)**
*(Gnomes are uncommon to rare)**

**Dwarves**
*(Struggle against modernity and Tradition. They have great political power but also many of the traditional, rural "Working Class" Dwarves are intenstly marginalized, oppressed and persecuted**)

**Elves**
*( Elves have a spiritual connection with their ancestor spirits, they share collective empathic memories with each other through their reverie, however there is a spiritual disease that is eroding eroding those memories, more and more they are feeling a loss of connection to the past and to themselves, causing madness, violence, intense paranoia and delusions at it's worst.)*

**Gnomes**
Gnomes are an ancestry that is on the verge of extinction. Long ago, they created a great city of wonders, but for some long ago forgotten reason, they used the power and knowledge of their society to hide the civilization. They locked it behind a great puzzle. In the aftermath, the diaspora left their people without a home. They were persecuted and killed by others seeking access to the power and wonderful knowledge of their society. Every since they have existed as scattered collections of nomadic groups and small secretive communities.

**Goblins**


**Humans**


**Medwen (Halflings)**


**Orc's:**


### Classes/Archtypes

Barbarian

Bard

Champions

Cleric

Druid

Fighter

Ranger

Rogue

Witch

Wizard






