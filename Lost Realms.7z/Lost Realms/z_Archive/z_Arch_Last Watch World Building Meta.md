Concepts (What the world is about)

- ##### Externalities
- #### Climate Change
- Compromise ()
- Liberation Theology - internal revolution ()

Overview
The world is on the brink of a catastrophe. The art of artificing is causing an imbalance in the nature of magic that will bring potentially world ending destruction. The Artificer's guild (or just The Guild) has revolutionized the world, and has conquered the world, through it's economy and influence. 

The continent of Ennarynn, once the home of the first civilization, is left to ruin. The corruption running rampant, and a long dark age changing it's landscape, both physical and political. The Guild has conquered the most desired fringes of it's continent but has left the it's heart untamed, using it as a sacrifice zone, fueling civil strife and sending undesirables into it.

Historical Ages

Creation
Rise of Dragon kind
The first societies
Birth of the Divine order
The Divine Wars
The Sundering.


Discovery of the Void
Discovery that magical artificing, the art of which the modern society is built, and the guild has gain it's power, is destroying the world.

A major endeavor is taken to reestablish a colony on the continent of Ennaryn, with the goal of trying to find a way to undo the rift. 

The guild co-opts the effort and the new colony's are quickly mired in civil strife, wars between old forgotten kingdoms and the oppressive rulership of the guild. 

(its sorta like now...we are fucked because the effort to do something about climate change was completely co-opted by capitalism)


Inspirations
Black Sails
Dark Water
Midnight
The Witcher (Netflix Series)
The Cover art from Eye of the World (the first one)
7th seas
Willow
Blades in the Dark
Death Gate Cycle



- magic shapes around people's ideas, changes them, they grow in power, change things around them, eventually ascend, they are revered, which slows magics change upon them. When they die they dissipate and are consumed into the consciousness.
- The Guild was a bunch of fucked up people living in a fucked up time that ordered things out of neccassity. their ancestors payed the costs for that. 
- normal technology happens (before magic) then magic introduced, and magic technology arises out of that.
- People in the "Zone" live in inferior more medieval standards. the closer to El Dorado, the more dark age, but not because of circumstance the reasons are because of society influences. We create the other. 
- Races (fantasy) existed because they were strong social ideas that were impressed upon them. The more free of those ideas they became the less the impact...although heritage exists. Some still exist...
	- isreal palestine conflict but the oppressed are "Morokai" pretty much orcs. same history and some blending but pretty much same political situation and history. \
- Magic Towers were a defense system for empire...empire falls after (Soviet Union Collapses) and then the Towers are turned inward keeping everyone in the zone. 