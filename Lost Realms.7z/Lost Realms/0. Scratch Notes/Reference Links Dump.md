[Obsidian TTRPG Website ](https://obsidianttrpgtutorials.com/): For anything Obsidian Tutorial Related.



[World Building Corner](https://www.worldbuildingcorner.com/) Vod's on world building.


[Color Hex Codes](https://www.color-hex.com/) 

[Word Hippo ](https://www.wordhippo.com/)

[How to make Character Sheets Article](https://polyhedralnonsense.com/2021/06/08/the-universally-complete-and-infallibly-correct-guide-to-creating-your-own-custom-rpg-character-sheet/)









