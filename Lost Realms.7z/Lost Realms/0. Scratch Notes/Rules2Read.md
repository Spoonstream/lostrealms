
How does NPC initiative from pets and conujured animals work?


Perception?

Traps