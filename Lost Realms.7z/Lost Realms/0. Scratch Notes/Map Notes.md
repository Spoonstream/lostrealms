# colors
Base Water: 093341
Shoreline: 125a72
Base Land (not exact to the tutorial): 223410 
Sandy Desert: ccb991
Rocky Desert: c0a915
Hot Grasslands (Savannah?): b19c6e
Regular Grasslands: 647031
Tropical Grasslands: 565c31
Temperate Rainforest: 45532d
Tundra: 5f604f
Ice Sheets: b3b4b2
Tiaga (Cold Plains/Grasslands): 2a3e1b
Lower Hieght Map: 4d4d4d
Greater Height Map: 414141
Ice caps: 63685f
Rivers: 0c364e
Dark Green Alternate: 34402c