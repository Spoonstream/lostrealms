
### Myths and Creation
En'nui'al - The first people
Dragons
Ancient Race's (titans and whatnot)
The first weapon
### Discordance
Big "fight" over everything. Basically creating things.
A big baddy creates a weapon and goes after the first people
### The Divine Revolt and The Sundering
Big War many sides. The First people retreat and sunder the world from the Aetherium.
Races go to sleep, some die, some are seperated from their vessels (spirits of the land and such)

### The Silent Age
First civilization of Humans, 
Elves, 
Dwarves, 
Gnomes, 
Medwin (Halflings). 
Goblins, 
Morokai (orcs)

This age is more or less science and technology advances

The Gnomish Subterrainian clockwork Empire. They build mega dungeon. Might be responsible for the reawakening. 
### Reawakening
Magic Returns. 
Gnomish empire dissappears mysteriously
Elven mage takes over the empire and acscends as a Eternal. Others Follow. 
### The Age of the Eternals
Magocracy civilization of conquest.
Boundary created.
Gates created.
### The Magus War
Conquered Kingdomes revolt against hte magocracy. 
Empire collapses and massive war + civil war breaks out.
Ends with multi empires.

### Rise of the Sovereign Council and The Reclamation.
Soviereign Council established based on the other continents
Guilds and Companies established.
Ennarynn Empire begins conquest - Using wyverns. Dragons secretly behind this. 
### The Talon Crusade 
The conquest of Ennarynn happens Sovereign War begins

Ends with the Seizure of the "Controls" of the boundary and the boundary is returned (again a mystery) 

### The Talon Civil War and Collapse.
Talon civil war and calamities begin to appear. 
