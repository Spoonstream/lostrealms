
# Lore Q&A v2

>>*I have converted these questions into a document for reference. The information can be readily "known" IC depending on your background, or can be assumed to be acquired passively in the universe. I will attempt to keep my answers brief, and am working some other game aids that should help you. I want to stress these things however:* 
>> - *This worldbuilding process is iterative, and may be subject to change. I will of course work hard to make sure we are all on the same page. Confusion is the enemy.
>> - World Building and Campaign Design are two seperate processes, that depend on each other. I am doing both (as well as doing my best to learn the actual rules). Please be patient. We don't have to figure out every detail at once.* 
>>  - *There are allot of unknowns at the moment. This is either because I have left room for both myself and you to create or contribute or because I am prioritizing. 
>>  - *I have am writing a lexicon of definitions for your reference. They are basically two to three sentence descriptions of any of the below.*
>>  *Last bit. When referring to our own real world I will use RW or IRW. When referring to the world and setting use LR (Lost Realms).*
>>  




So, what would be common knowledge for us, collectively? (doesn't mean we particularly know, but it's easy information to find if you're not isolated, etc). Add; "does it depend on other factors?" "Is it unique to different groups?" to the end of these.

>> I will attempt to make these answers broad. The more or less isolated you are might alter the depth or detail of understanding but that is a one on one conversation. These answers you can assume to know in at least the most basic sense. If you have any qualms then assume that you understand the most basic and we can dial it in during game.

What collective history/experiences are we aware of in regard to your world?
>> You can be aware of the Ages and generally what happened, or at least the popular version of it. Here is a break down and some description of the ages. This will be the longest answer because it is a timeline essentially.  
>> - **Age of Creation** - Two beings created the universe and all the things. Any imaginable variation of the creation of Lum'rin'el. 
>>- **The Discordance** - All the newly created beings conflicted and created things themselves, it was a chaos and harmony, think RW greek myths and things of that nature. This age ends with the first appearance of [[The Eternals]]. 
>> 	**The Eternals** - Mortal beings who took power, usurped the creators and the rest of their creations and sundered the realms of Lum'rin'el from the Aetherium after ascending into the aether. This event trapped beings from all over the cosmos - and caused a massive calamity. It also severed the direct connection to the [[Aetherium]]  and magical energies forever (I am still debating on the term for magic energies). I stress that every variation says that they gained their power from somewhere or something else, usually variations of the story portray them using force. The Eternals are deities by virtue of their actions. 
>> - **Age of Wonders** - First ancient civilizations mostly of species that came after the first species. These are all heavily mythologized, things like titans, dragons, and other supernatural beings are said to have existed during this time. 
>> 	- Gnomes and Elves are the only two ancestries that appear during this age within modern civilization. 
>> 	- It is said that there was a city built by gnomes said to contain magical creations and wonders. It was lost during this time, and has never been found (think RW El Dorado or Atlantis)
>> 	- This age ends with the Sundering in what is called the Divine Revolt, a war that took place between the First Races, the Creators, and the new races. 
>> - **Age of The Long Night**
>> 	- Great calamity and then in aftermath. In the wake new societies are built. 
>> 		- There is no arcane magic during this age. Slowly (as faiths emerge) the use of divine magic is "discovered", and grows. 
>> 		- Society largely rebuilds itself along technological lines, although more rapidly than RW, reaching RW dark age (circa 800-900 ad) levels of development. 
>> 		- Monarchies are established as individuals claiming "divine rights", who wield power relics that are believed to have been given to them by the Eternals. They establish many isolate kingdoms and long era marked by wars and feuds dominates the end of this age.
>> 		- The first Human societies emerges during this period. 
>> 		- This age ends with the appearance of Thaelos Fate-Changer and return of arcane magic.
>> - **Imperial Age**
>> 	- Thaelos Fate-Changer appears, armed with magic him and his followers begin conquering the many isolated and feuding kingdoms. He establishes the Thaelon Empire, a Magocracy, that within the century spans the entire world of Lum'rin'el.
>> 		- Gateways are created during this time. Gateway travel remains the most efficient and principle means of transport over long distance during this time. 
>> 		- The Boundary was created during this time (although no one would no it until it came to life mysteriously much later). 
>> 		- Arcane Magic was developed during this time. Thaelos is regarded as the person that discovered it, but no one knows where he gained this ability.
>> 		- Thaelos rules autocratically. However he is viewed mostly as a positive force for progress, equality, and justice.
>> 		- Thaelos disappears mysteriously. This is not only a well known fact. The reasons for his disappearance are also unknown, although there are many theories. Feel free to make up your own version or story that your character was told.
>> 		- After his disappearance the empire persists, ruled by the councilor's and ministers. The empire exists for another 700 years after his disappearance but corruption and societal decay eventually bring about its collapse and dissolution. 
>> 		- This era is marked by the declaration by territories on the other continents and along the coastal regions of Enarynn of independence from Imperial control. 
>> - **Age of Reformation**
>> 	- The age begins with an era known as the Warlock Wars. One war against the empire that quickly devolves into a many wars as the empire divides into factions. These are devastating war and destruction on a scale that has never been since, These end with the world in ruin and treaty know as the Reconciliation, by the surviving nations.
>> 	- The Reconciliation establishes the Conscilium (magical policing, and enforcement), the recognition of the perennial church (see below), "international" laws and regulations concerning magic use.
>> 	- During this time the disparate faiths of The Eternals convene and form the Perennial Faith, and combined worship and doctrine of the Eternals. 
>> 	- The later half of this age see's the rise of the artifice and enchantment guilds in spread across the many kingdoms and nations. 
>> 	- The age ends with the appearance of disease and plague called the Blight.
>> - **The Age of Anathema**
>> 	- A massive outbreak of plague surges over the civilization . Spreading from a crop famine, disease and fear cause massive death. 
>> 	- This results in civil unrest. Coups, revolts, wars and insurgencies are the hall mark of this era known as the Malediction. 
>> 	- The first use of necromancy appears during this time. This instigates a long period of time known as the Death Bringers War. As many kingdoms fight armies and conspiracies empowered by the new death magic. 
>> 	- This age comes to an end when the Boundary (the magical barrier that currently separates Enarynn from the rest of the world) springs to life for an unknown reason. The Gateway system is disrupted and shuts down. All by the Gateways to and from Gates behind the boundary are re-established. The majority of Enarynn is severed from the civilized world. 
>> - **The Modern Age**. 
>> 	- 179 years pass with since the Boundary activated. 
>> 	- During this time the Soveriegn Kingdoms are established. (I will have an aid that explains more about this)
>> 	- The Guids rise to power. 
>> 	- 10 years ago, a band somehow penetrates the barrier and re-establishes the gateway from within the Boundary. 


What facts do we collectively have proof for?
>> That is hard to answer even for us IRW. However there are remnants in the form of ruins, movements and records. While literacy is much higher than RW medieval or renaissance, most of the oldest records however were located on Enarynn itself (the majority behind the Boundary). So accounts and determination of "facts" could be subject to skepticism by us IRW. In LR though, mostly trust, faith and authority is used over objective analysis for most of society. The exception is the Medweni (halflings) whose, dominate cultural influence has cultural pre-occupation for finding or determining "Truth".

What kind of proof is it, if any?
>> I believe the bulk of this answer can be determined using answer to this previous question. One major influence I would like to point out is the intervention or communication with The Eternals and spiritual patrons. Also oracular magical abilities or practices could constitute for most people as proof. 
>> The main point I want to make is objectivity is much more valued in RW society than it is in LR. That is because of the lack of influence by science over it's development, the intervention of spiritual and divine beings, and the ways in which long distance or mass communication exists (or doesn't).

What kind of governments have we experienced/been aware of?
>>Much like our own world, the most common form government are monarchies. [[The Sovereign Kingdoms]] are dominated by Aristocratic, Oligarchical (rule by few), Autocratic (direct rule by one), Democratic, Timocratical (rule by property owners), Monarchist (rule by one person for life) and Theocratic (ruled by divine law) governments. Tribes and other loosely stateless government structures exist but are not formally recognized by [[The Sovereign Kingdoms]]. Communism or hasn't been excluded but doesn't formally exists. 

 Are we aware of any "rebellious factions" like, world, universe, etc famous.
>> Practitioners of Necromancy were persistant outside of the boundary but was banned believed to have been eliminated in [[The Sovereign Kingdoms]]. 

What are their aims that we would know, if any?
>> Necromancer's did evil shit to everyone and they want to destroy the world. They are rabid fanatics.

 Are we aware of foreign customs?
>> You can be if it involes one of the other characters...people can teleport. 

Are we exposed to travelers, merchants, etc?
>>Traveler's - If you come from an urban area, yes probably you have encountered traveler's. If you are from a rural area not as much.
>Merchants - Traveling merchants? If you are from a rural area then yes. if you are from an urban area then no. Most things produced are made from materials that are refined somewhere else...so even rural area's are dependent on a supply chain. This is enforced by laws made to uphold treaty with the guild. 

What is the general feel for religions, worshipping, religious centers, buildings, areas, etc.?
>>By treaty each Sovereign kingdom must sequester a portion of land for the Perrinial Faith, within each population center above a certain amount. this doesn't apply to any territory outside of their jurisdiction (such as the frontier).

What is the general "class" situation? Is it like modern-world? (i.e. poor, rich, rich hoard, poor live in simple areas, etc.) or is it something different, similar, etc?
>>Class structures (generally speaking) are very much what you would assume them to be. Rich people and poor people. 

How are women treated?
>> Because of many different reasons, I won't go into here from magic, to the differences in faith, longer life spans, and longer life expectancies. Women are treated equally and have greater equity than RW. The principle reason is I never rp abuse or sexism. 

How are children treated?
>>By our RW standards, children are brought up stricter generally. Every child living within [[The Sovereign Kingdoms]], at the age of 10, is subjected to an aptitude test. Which can result in them gaining entrance into a guild, or relegated to non-magical occupation. Sometimes a child mandated to undergo arcane training and sent to a wizard for apprenticeship. This is enforced by the Conscilium and those that do not adhere to that mandate are arrested, if they have not presented themselves within a year. 
>>Children are educated at trade schools generally, in which they are boarded and spend the majority of the year, they only leave during the summer months to stay with their family or on special holidays in some countries. 
>>Outside of [[The Sovereign Kingdoms]] children are home taught, raised and taught by community or mentored by individuals (the reasons and education varies).


How is eating/drinking approached (feeding and hydrating)?

>> Very much similar to boiler plate fantasy...there are no changes here. pubs and taverns. People cook over fires. The only exception is water purification is a widely distributed practice and pure water is more readily available. 


*

What role does science and medical science play?
>>This is perhaps the most important element that I have been unable to form into words until you asked these questions. 
>>Lost Realms is a Fantasy, specifically I am attempting to create a setting that is both High Fantasy and Low Fantasy. High Fantasy meaning magic is readily apparent almost common and Low Fantasy that magic is rare, uncertain, and the setting is very much grounded. This is a very hard balance to strike though, because in most High Fantasy settings magic either substitutes science and  innovation, or it is *fantastic* and completely subverts realism. 
>>In this setting technological innovation was stunted after development equivalent to the dark ages (600-800 AD). This is because of the dramatic intervention of magic into into societies development. Before that access to magic was dependent on faith, which was inaccessible because of political and travel limitations. Once magic changes the course of development, the role of innovation and scientific thinking change. Magic has been incorporated to compliment dark age, medieval and even renaissance, methods of production 
>>When it pertains to medicine. People have village healers and natural medicines are predominant in isolated or rural area's, however these are used also commonly with magical means of treatment. Urban area's have much greater access to medical services and enjoy much cleaner and healthier living standards (such as clean water and food). Those services are much more commonly provided by the Perennial Faith.


Are there common knowledge warnings about where we should/should not go, and that spectrum?
>>> I can't think of any actively that would be common across the board. There are probably some things but it would have to be a case by case, in the moment judgement. 


What do we know about common flora and fauna? 
>>> I have not gotten to some of the special or exotic plants or flora as of yet. They do exist, and they will be pertinent at very minimum for alchemy. 
>>> I will add that leshy (the plant people) do exist, however they are dramatically different than described in the book. They are cursed individuals, in a similar manner to lepers. 

Do we all know how to "act" around certain classes, elders, gods, you know...do we know how to put on the appropriate masks for groups that is common knowledge?

>> I would tell you that it might be wise to assess the capabilities of a person before you do something that might piss them off. There will be times that I will have written down stats for NPC's and such or determined what there level is before game session. We are working under power without level special rule, it is should not be assumed that I am scaling them to your level and power. 

If commonly seen, describe the sky in different weather types, seasons, during an entire day and night, etc.

>> um no... that would be something that would be better for the game session even at the table. I appreciate the need to picture something, but those types of descriptions, I reserve for when I want to invoke certain levels of immersion or mood for you. 

Are the seasons different here? 
>>No...although weather has been markedly more severe in last couple of decades.

What would be a common to least common season to be born?
>> Spring and Summer generally....travel during winter is very much restricted. Urban area's people have a greater portion of births during other seasons. 

Does being born in certain seasons/times of day/areas, etc mean anything?

>>Religion and Spirituality have a strong role...so yes. Portents omens, and signs have much more meaning. 

What are common superstitions?

>>There are many superstitions about the practice of magic (meaning spell casting not the magic used by the guild known as guild craft). Knowledge about what magic does and does not do causes fear and mistrust.
>>Urban communities or communities located close to urban communities generally have a mistrust of people that practice Primal magic, or are generally from frontier lands or live in the wilderness communities. Rural farming and agricultural population centers are mistrusting or pretty much anyone for a variety of reasons and have many superstitions. 

Is there a problem with intoxicants? Or is it "a problem, but not one to do with this world?"

>> For the most part no. Alchemical concoctions have been banned by the guild and most sovereign kingdoms enforce that policy actively. Although you can get the stuff.

What about vermin?

>>>There will be rat people....I am a huge fan of Scaven from 40k so be warned.

What about plagues?

>> The plague mention above is the largest plague in recent recorded history. It died out, but for the most part diseases spreading widely isn't as common as RW history. The presence of active social services that can remove disease generally prevents diseases from spreading to wide. However there are diseases, usually in more isolated situations, associated with certain segments of society, location, social status, or the lack of religious services. Additionally magical diseases do exist, but at this time I have not created a instance of a plague historically.

What about agriculture, food production, animal slaughter, consumption of meat, hunting, etc. Is there common knowledge of processes, laws in certain places, etc?

>>This might be oversimplified version of this answer...but you know who you are asking this question to, and you probably don't want a dissertation on the production cycle of my setting. 
>>- Magic rituals are used by guilds (who are affiliated with the property owners of land) to produce more goods with less labor. 
>>- This has caused society to be less dependent on rural agricultural labor (i'e farmers) and as a consequence people have gravitated more towards urban areas. It has also left rural populations more isolated (generally).
>>- In rural area's skills sets required for personal subsistence (meaning eating and living) are much more common. In urban area's not as much. 
>>- Laws against personal agriculture are strict where they are necessary in rural area's but for the most part exist on paper and never need to be enforced, so common knowledge about specific laws generally doesn't exist (that is a character background thing). If that doesn't make sense, think of taxes. Yeah you know that people pay taxes for various things, but there are probably quite a few taxes you don't know, and never heard of people getting punished for not paying (even though it still happens).
>>- The one laws that is the exception, is the laws prohibiting the wide spread use and practice of druidic blessings, specifically to interfere with production. There is an event that has happened, of violence against druids, but I haven't worked out the details. 

What about the "laws when the domed continent wasn't domed?" are they different than now? 

>>>Common knowledge is more or less the assumption that laws were much more lax but more or less the same. 

What do we know about the whole, "seeker job" as I understand it, we're a crew tasked to "mine a resource(s) in the "domed continent" in that we're "liberating it." So, what is that culture like, the "thieves, robbers, criminal underground?"

>>>Charter Companies are a newer "profession" that was made popular by the reclamation proclamation. As far as most people would be aware it is a life of adventure and opportunities. Think of it like the gold rush (because that is what it is essentially).

And of course, what is largely fashionable as far as clothing, colors, homes, entertainment, food, drink, music, stories, styles of lands (efficiency-wise I would imagine).

>>>Honestly I have no idea...that is something I developing as I go. 

How is courtship generally? What is considered "Standard" vs. what is considered "out of the norm" and "unacceptable/offensive/sinful, etc"

>>> I haven't created any specific differences other than the ones that would naturally be assumed in a more gender equal society. I am also using the acceptable age standards of RW. so no marrying kids off...
>>> Arranged marraiges are much more common though. 

In the same vein, what is generally considered "unacceptable/offensive/sinful, etc." Like, incest, murder, dueling, stealing, scalping, price gouging, beating, hurting, self-defense, etc.

>>> Assume the normal anti stealing, no murder, etc etc...it is a fantasy setting so people can be armed and defend themselves. Specific "sins" or "crimes" are very much something I determine as we go, specific to induvial, cultures or religious belief systems, can and will vary, and not specified at this time (I am getting to the Eternals and edicts/anathema soon, as well as the new alignment systems) 

General laws we would know. 

>>Don't fuck with the guild, spellcasting is prohibited in some places or locations ((by law, and yes there are "mage police"), and paperwork and documentation are used much more than your run of the mill fantasy setting. 

Attitudes toward pets, nurturing, helping, etc.

>> This is really vague...pets are well pets...there are some crazy wierd ones? I actually need a little bit more about what you mean on this...I haven't thought of anything in particular yet if that is what you are asking. 

Is society generally toward helping others, or toward self-first, or something else?

>>>Actually one of the earliest decisions I made was that community, relationships and agreements have much more meaning than other settings. People in this setting gravitate towards community and groups. Despite the obvious greed of the guilds, they are really held together by groups of people loyal to each other and looking out for other, they persist out of a desire for social welfare. Specifically that is why the Covenant system (my house ruled mechanic for the charter companies) is designed the way it is, because I wanted the mechanic to reflect the narrative.