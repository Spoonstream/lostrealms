
Task List Sorted by priority
1) Blue Book 
2) Write Session Outline 
	1) NPC's 
		1) Cimmon
		2) Dude in the Box
3) Github or One Drive Obsidian 
4) Covenant Sheet
	1) Effective way to do drives at the beginning of the game session. 
5) Lexicon work
6) World Building 
	1) [[Gerdanya]] 
	2) [[Mal'Kryinnis]] 
	3) [[Ozrevon]] 
	4) Druids
	5) Language heirarchies and mechanics. Skill tree system from SR2 
7) Prep for Investigation and Combat rules.
	1) Perception, stealth, and social rumor mongering
	2) basic combat stuff.
8) Work on progression system 
	1) Read XP rewards look at some scenerios to judge progression

