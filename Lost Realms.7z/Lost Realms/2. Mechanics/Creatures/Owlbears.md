
# Owlbear (Normal) 

# [![PFS Standard](https://2e.aonprd.com/Images/Icons/PFS_Standard.png "PFS Standard")](https://2e.aonprd.com/PFS.aspx)Owlbear (Normal) 

With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech only seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.  
  
Although their origin is lost to time, owlbears are assumed to be the result of a magical experiment to make a more cunning predator. According to the legend, the wizard was too successful and ended up being the flrst victim of the beast. Today, owlbears can be found around the world, with a variety of features. While the most common subspecies looks like a brown bear with the features of a great horned owl, owlbears from the frozen north might resemble polar bears mixed with snowy owls, and in temperate rain forests they might resemble black bears with the heads of barn owls.  
  
Most owlbears live solitary lives, gathering only to mate and raise cubs, which are hatched from eggs. An owlbear’s territory usually extends to around 5 miles from its lair, with clear signs of its habitat appearing with 1 mile (clawed up trees, gigantic feathers, and shredded carcasses). The lair of an owlbear rarely holds anything of value, but some adventurers have found trinkets, coins, and even jewelry in the massive pellets of undigested bones these monsters leave behind.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 19  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 17  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 14](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=328&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=328) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=328&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=328&PWL=true)

## [Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)Creature 4

[![](https://2e.aonprd.com/Images/Monsters/Owlbear.png)](https://2e.aonprd.com/Images/Monsters/Owlbear.png)[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
**Perception** +13; low-light vision, scent (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +7, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +14, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +10  
**Str** +6, **Dex** +1, **Con** +5, **Int** -4, **Wis** +3, **Cha** +0

---

**AC** 21; **Fort** +13, **Ref** +7, **Will** +11  
**HP** 70

---

**Speed** 25 feet  
**Melee** [one-action] talon +14 [[+10/+6](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170)), **Damage** 1d10+6 piercing plus Grab**Melee** [one-action] beak +14 [[+9/+4](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+6 piercing**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC 20 Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is [frightened 2](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Critical Failure** The creature is fleeing for 1 round and [frightened 3](https://2e.aonprd.com/Conditions.aspx?ID=19).**Gnaw** [one-action] **Requirements** The owlbear has a creature grabbed with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC 22 Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34) and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains [sickened](https://2e.aonprd.com/Conditions.aspx?ID=34).**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Variant Owlbears

Snowy owlbears trade their terrifying screech for amazing stealth and the learned ability to erupt from the snow to take prey by surprise. Although incredibly rare, some owlbears have retained a limited form of flight, allowing them to glide almost 20 feet for every foot of height descended. Terrifyingly, these gliding owlbears are entirely silent while descending on their prey.

## All Monsters in "[Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)|5|
|[Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)|4|

## [Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)

**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech only seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.




# [![PFS Standard](https://2e.aonprd.com/Images/Icons/PFS_Standard.png "PFS Standard")](https://2e.aonprd.com/PFS.aspx)Owlbear (Prof w/o Level)

With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech only seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.  
  
Although their origin is lost to time, owlbears are assumed to be the result of a magical experiment to make a more cunning predator. According to the legend, the wizard was too successful and ended up being the flrst victim of the beast. Today, owlbears can be found around the world, with a variety of features. While the most common subspecies looks like a brown bear with the features of a great horned owl, owlbears from the frozen north might resemble polar bears mixed with snowy owls, and in temperate rain forests they might resemble black bears with the heads of barn owls.  
  
Most owlbears live solitary lives, gathering only to mate and raise cubs, which are hatched from eggs. An owlbear’s territory usually extends to around 5 miles from its lair, with clear signs of its habitat appearing with 1 mile (clawed up trees, gigantic feathers, and shredded carcasses). The lair of an owlbear rarely holds anything of value, but some adventurers have found trinkets, coins, and even jewelry in the massive pellets of undigested bones these monsters leave behind.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 19  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 17  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 14](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=328&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=328) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=328&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=328&PWL=true)

## [Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)Creature 4

[![](https://2e.aonprd.com/Images/Monsters/Owlbear.png)](https://2e.aonprd.com/Images/Monsters/Owlbear.png)[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
**Perception** +**9**; low-light vision, scent (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**3**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**10**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**6**  
**Str** +6, **Dex** +1, **Con** +5, **Int** -4, **Wis** +3, **Cha** +0

---

**AC** **17**; **Fort** +**9**, **Ref** +**3**, **Will** +**7**  
**HP** 70

---

**Speed** 25 feet  
**Melee** [one-action] talon +**10** [[+6/+2](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170)), **Damage** 1d10+6 piercing plus Grab**Melee** [one-action] beak +**10** [[+5/+0](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+6 piercing**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC **16** Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is [frightened 2](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Critical Failure** The creature is fleeing for 1 round and [frightened 3](https://2e.aonprd.com/Conditions.aspx?ID=19).**Gnaw** [one-action] **Requirements** The owlbear has a creature grabbed with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC **18** Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34) and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains [sickened](https://2e.aonprd.com/Conditions.aspx?ID=34).**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Variant Owlbears

Snowy owlbears trade their terrifying screech for amazing stealth and the learned ability to erupt from the snow to take prey by surprise. Although incredibly rare, some owlbears have retained a limited form of flight, allowing them to glide almost 20 feet for every foot of height descended. Terrifyingly, these gliding owlbears are entirely silent while descending on their prey.

## All Monsters in "[Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)|5|
|[Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)|4|

## [Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)

**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech 
nly seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.




# [![PFS Standard](https://2e.aonprd.com/Images/Icons/PFS_Standard.png "PFS Standard")](https://2e.aonprd.com/PFS.aspx)Zombie Owlbear

Zombie owlbears combine an [owlbear's](https://2e.aonprd.com/Monsters.aspx?ID=328) ferocity with mindless undead hatred. Once it draws near, it often stands up, unleashing a guttural, wet roar, before charging into combat without thought of self-preservation.  
  
**[Recall Knowledge - Undead](https://2e.aonprd.com/Rules.aspx?ID=563) ([Religion](https://2e.aonprd.com/Skills.aspx?ID=13))**: DC 18  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 16  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 13](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=1920&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=1920) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=1920&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=1920&PWL=true)

## [Zombie Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=1920)Creature 3

[![](https://2e.aonprd.com/Images/Monsters/Zombie_ZombieOwlbear.png)](https://2e.aonprd.com/Images/Monsters/Zombie_ZombieOwlbear.png)[NE](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Mindless](https://2e.aonprd.com/Traits.aspx?ID=108) [Undead](https://2e.aonprd.com/Traits.aspx?ID=160) [Zombie](https://2e.aonprd.com/Traits.aspx?ID=245)   
**Source** [_Book of the Dead pg. 171_](https://2e.aonprd.com/Sources.aspx?ID=118)  
**Perception** +8; [darkvision](https://2e.aonprd.com/MonsterAbilities.aspx?ID=12)  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +5, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +12  
**Str** +4, **Dex** +0, **Con** +3, **Int** -5, **Wis** +1, **Cha** -3  
**Slow** A zombie owlbear is permanently [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) and can't use reactions.

---

**AC** 16; **Fort** +8, **Ref** +5, **Will** +6  
**HP** 85 ([negative healing](https://2e.aonprd.com/MonsterAbilities.aspx?ID=42)); **Immunities** [death](https://2e.aonprd.com/Traits.aspx?ID=40) effects, [disease](https://2e.aonprd.com/Traits.aspx?ID=46), [mental](https://2e.aonprd.com/Traits.aspx?ID=106), [paralyzed](https://2e.aonprd.com/Conditions.aspx?ID=28), [poison](https://2e.aonprd.com/Traits.aspx?ID=126), [unconscious](https://2e.aonprd.com/Conditions.aspx?ID=38); **Weaknesses** [positive](https://2e.aonprd.com/Traits.aspx?ID=128) 10, slashing 10

---

**Speed** 25 feet  
**Melee** [one-action] talon +12 [[+7/+2](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d10+7 piercing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Melee** [one-action] beak +12 [[+7/+2](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+7 piercing**Ground Slam** [two-actions] ([attack](https://2e.aonprd.com/Traits.aspx?ID=15)) **Requirements** The zombie owlbear has a creature [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) or [restrained](https://2e.aonprd.com/Conditions.aspx?ID=33) with its talons; **Effect** The zombie owlbear repeatedly slams the creature into the ground. This deals 1d10+7 bludgeoning damage (DC 20 [basic](https://2e.aonprd.com/Rules.aspx?ID=329) Fortitude save). On a critical failure, the creature is [stunned 1](https://2e.aonprd.com/Conditions.aspx?ID=36), and on a critical success the creature is no longer grabbed or restrained.**Horrifying Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The zombie owlbear unleashes a broken, snarling screech that unnerves those who hear it. Each creature in a 60-foot emanation must attempt a DC 19 Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is frightened 2.  
**Critical Failure** The creature is [fleeing](https://2e.aonprd.com/Conditions.aspx?ID=17) for 1 round and frightened 3.

## All Monsters in "[Zombie](https://2e.aonprd.com/MonsterFamilies.aspx?ID=103)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Zombie, Dirge Piper](https://2e.aonprd.com/Monsters.aspx?ID=2036)|3|
|[Husk Zombie](https://2e.aonprd.com/Monsters.aspx?ID=1919)|2|
|[Plague Zombie](https://2e.aonprd.com/Monsters.aspx?ID=424)|1|
|[Shambler Troop](https://2e.aonprd.com/Monsters.aspx?ID=1376)|4|
|[Zombie, Shock](https://2e.aonprd.com/Monsters.aspx?ID=1985)|6|
|[Sulfur Zombie](https://2e.aonprd.com/Monsters.aspx?ID=1377)|6|
|[Withered](https://2e.aonprd.com/Monsters.aspx?ID=1922)|5|
|[Zombie Brute](https://2e.aonprd.com/Monsters.aspx?ID=425)|2|
|[Zombie Dragon](https://2e.aonprd.com/Monsters.aspx?ID=1378)|9|
|[Zombie Hulk](https://2e.aonprd.com/Monsters.aspx?ID=426)|6|
|[Zombie Lord](https://2e.aonprd.com/Monsters.aspx?ID=1921)|4|
|[Zombie Mammoth](https://2e.aonprd.com/Monsters.aspx?ID=1923)|11|
|[Zombie Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=1920)|3|
|[Zombie Shambler](https://2e.aonprd.com/Monsters.aspx?ID=423)|-1|
|[Zombie Snake](https://2e.aonprd.com/Monsters.aspx?ID=1918)|0|

## [Zombie](https://2e.aonprd.com/MonsterFamilies.aspx?ID=103)

**Source** [_Bestiary pg. 340_](https://2e.aonprd.com/Sources.aspx?ID=2)  
A zombie's only desire is to consume the living. Unthinking and ever-shambling harbingers of death, zombies stop only when they're destroyed.

## Zombie Abilities

You can modify zombies with the following zombie abilities. Most zombies have one of these abilities; If you give a zombie more, you might want to increase its level and adjust its statistics. The DCs use the zombie's level from the [Spell DC and Spell Attack Bonus](https://2e.aonprd.com/Rules.aspx?ID=1020) table.  
**Disgusting Pustules** ([disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie is covered in pustules that rupture when it takes any piercing damage or any critical hit. In either case, adjacent creatures are hit with vile fluid, causing them to become sickened 1 unless they succeed at a Fortitude save.  
**Feast** [two-actions] ([manipulate](https://2e.aonprd.com/Traits.aspx?ID=104)) If the zombie is adjacent to a helpless or unconscious creature, or a deceased creature that died in the past hour, the zombie can feast upon its flesh to heal itself. This restores an amount of Hit Points equal to the zombie's level. If the creature is alive, the zombie deals damage equal to its jaws, flst, or claw damage.  
**Plague-Ridden** ([disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie carries a plague that can create more of its own kind. This functions as the plague zombie's zombie rot, except at stage 5, the victim rises as another of the zombie's type, rather than a plague zombie.  
**Rotting Aura** ([aura](https://2e.aonprd.com/Traits.aspx?ID=206), [disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie emits an aura of rot and disease that causes wounds to fester and turn sour. Any living creature that starts its turn within 10 feet of the zombie and is not at full Hit Points takes 1d6 damage as its wounds fester. This damage increases by 1d6 for every 6 levels the zombie has. Creatures that take a critical hit from the zombie also take this damage immediately.  
**Unkillable** This zombie is nigh unkillable. The zombie loses its weakness to slashing and gains resistance against all damage equal to its level (minimum 3), and it gains weakness equal to twice its level (minimum 6) to critical hits. Increase the zombie's level by 1 if you give it this ability.

## Addit

ional Monster Abilities

### Bestiary 3

You can modify zombies with the following zombie abilities, in addition to those found on page 340 of the _Bestiary_. Most zombies have one of these abilities; if you give a zombie more, you might want to increase its level and adjust its statistics.  
  
**Ankle Biter** This zombie fights just as well on the ground as it does standing. While [prone](https://2e.aonprd.com/Conditions.aspx?ID=31), the zombie isn't [flat-footed](https://2e.aonprd.com/Conditions.aspx?ID=16), it ignores the status penalty to its attack rolls, and it gains a +2 circumstance bonus to [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) checks to [Trip](https://2e.aonprd.com/Actions.aspx?ID=40). The zombie can also move up to half its Speed when it [Crawls](https://2e.aonprd.com/Actions.aspx?ID=76).  
  
**Persistent Limbs** The first time the zombie is critically hit with a melee or ranged Strike, a limb falls off its body and continues to attack. The limb acts on the zombie's initiative; each round it can Stride up to half the zombie's Speed and make a Strike. The limb uses and contributes to the zombie's multiple attack penalty.  
  
**Putrid Stench** ([aura](https://2e.aonprd.com/Traits.aspx?ID=206), [olfactory](https://2e.aonprd.com/Traits.aspx?ID=246)) 15 feet. The zombie's rotting flesh is particularly malodorous. A creature that enters the area must attempt a Fortitude save. On a failure, the creature is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34), and on a critical failure, the creature also takes a –5-foot status penalty to its Speeds for 1 round. While within the aura, the creature takes a –2 circumstance penalty to saves to recover from the sickened condition. A creature that succeeds at its save is temporarily immune to all zombies' putrid stenches for 1 minute.  
  
**Unholy Speed** The zombie gains a +10 status bonus to all its Speeds

### Book of the Dead

**Infested** The zombie's flesh is infested with swarming vermin. When the zombie is hit with a critical hit or destroyed, the [swarm](https://2e.aonprd.com/Traits.aspx?ID=239) is set free. Its initiative is immediately after the zombie's. If the swarm is 4 or more levels lower than the zombie, it isn't worth XP (and doesn't add its XP to the encounter budget).  
  
**Spitting Zombie** The zombie spits acid as a ranged Strike with a range of 30 feet. This uses the highest attack bonus among the zombie's Strikes and deals 1d12 acid damage per 3 levels of the zombie (or 1d6 acid damage below level 3). On a critical hit, the target also takes 1d4 [persistent acid damage](https://2e.aonprd.com/Conditions.aspx?ID=29) per 3 levels of the zombie. Once used, the zombie must spend 1 action to cough up enough acid to use this ability again.  
  
**Tearing Grapple** The zombies work in groups to rip foes to pieces. Whenever a zombie with this ability successfully [Grapples](https://2e.aonprd.com/Actions.aspx?ID=35) a foe that's already [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) or [restrained](https://2e.aonprd.com/Conditions.aspx?ID=33) by another zombie with this ability, they violently struggle over the poor victim, dealing fist damage (or a similar Strike's damage if the zombie doesn't have a fist Strike). If the grapple is a critical success, the target takes double damage and ceases being grabbed or restrained by any other creatures. If the zombie has the [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18) ability, using Grab deals half its fist Strike damage to the target.

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Creating Zombies

To create a zombie creature, start with a zombie of the appropriate size. Then add any Strikes, Speeds, or other abilities it would gain from its shape. To create a Gargantuan zombie, begin with the zombie hulk, apply the elite adjustments, change its size to Gargantuan, and increase its reach by 5 feet.

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Disposable Legions

With the ancient lich Tar-Baphon now released from his ages-long imprisonment, the undead within his legions have been specifically repurposed. Zombies like the ones seen here fulfill particular roles, and evil necromancers deploy them much like living or intelligent undead troops. Necromancer experiments seek to produce various abilities and mix energies, with horrifying results that doesn't deter their creators.

### ![Sidebar - Treasure and Rewards](https://2e.aonprd.com/Images/Icons/Sidebar_5_TreasureAndRewards.png "Sidebar - Treasure and Rewards")Hoarding Instincts

Though zombies have no use for wealth—indeed, most don't understand the concept in the first place—zombie dragons retain a hint of their innate tendency to hoard. A fresher corpse might guard the hoard it gathered in life (or what remains of it), while a zombie further from life might instead hoard bones, rocks, corpses, or other unusual objects. Understandably, the monetary value of these hoards varies widely

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Mindless Mix-Ups

Zombies try to obey orders, but understanding the words spoken doesn't always mean interpreting them correctly. Examples of misunderstood orders have included the following.

- “Fetch my hat,” leading the zombie to spend hours throwing a hat across a room and retrieving it.
- “Prune these bushes,” resulting in bushes “pruned” entirely, cut off at the root.
- “Let me know if anyone comes to the door,” causing the zombie to go to the door and return to its master.
- “Kill the intruders!” turning zombies raised from a local graveyard against their master, who was not from the area.

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Risen from the Grave

Zombies are often created using unwholesome necromantic rituals. Among the living dead, zombies are most often used as fodder, wearing down defenses and consuming resources before more powerful undead arrive to deal the killing blow. Zombies cannot speak or really even think for themselves, but they can be commanded by other allied undead and powerful necromancers.

### ![Sidebar - Geb](https://2e.aonprd.com/Images/Icons/Sidebar_6_Geb.png "Sidebar - Geb")Symphony of Flesh

Life creates flesh to fulfill its needs, growing it to hunt, consume, and survive. In undeath, the tools of survival can be made into a medium for art. The zombie is the first note in a symphony of dead flesh. Along with skeletons, they are the sturdy, reliable base of any masterpiece and an artist who fails to master these simple tools is not worth notice. One can hear the joyous sounds of the symphony in the low moans and creaking bones of a zombie legion.

### ![Sidebar - Related Creatures](https://2e.aonprd.com/Images/Icons/Sidebar_4_RelatedCreatures.png "Sidebar - Related Creatures")Zombie Animals

Animals, like the [snake](https://2e.aonprd.com/MonsterFamilies.aspx?ID=93), [owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328), and [mammoth](https://2e.aonprd.com/Monsters.aspx?ID=202) found here, can easily turn into zombies. They commonly rise from areas cursed by necromancy rather than being deliberately created. [Risen pets](https://2e.aonprd.com/MonsterFamilies.aspx?ID=309) sometimes develop a fondness for zombies, especially zombies of their former owners. An ordinary zombie can be a suitable companion, capable of petting the risen pet endlessly without the capacity to grow bored


# [![PFS Standard](https://2e.aonprd.com/Images/Icons/PFS_Standard.png "PFS Standard")](https://2e.aonprd.com/PFS.aspx)Zombie Owlbear (Prof w/o Level)

Zombie owlbears combine an [owlbear's](https://2e.aonprd.com/Monsters.aspx?ID=328) ferocity with mindless undead hatred. Once it draws near, it often stands up, unleashing a guttural, wet roar, before charging into combat without thought of self-preservation.  
  
**[Recall Knowledge - Undead](https://2e.aonprd.com/Rules.aspx?ID=563) ([Religion](https://2e.aonprd.com/Skills.aspx?ID=13))**: DC 18  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 16  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 13](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=1920&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=1920) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=1920&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=1920&PWL=true)

## [Zombie Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=1920)Creature 3

[![](https://2e.aonprd.com/Images/Monsters/Zombie_ZombieOwlbear.png)](https://2e.aonprd.com/Images/Monsters/Zombie_ZombieOwlbear.png)[NE](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Mindless](https://2e.aonprd.com/Traits.aspx?ID=108) [Undead](https://2e.aonprd.com/Traits.aspx?ID=160) [Zombie](https://2e.aonprd.com/Traits.aspx?ID=245)   
**Source** [_Book of the Dead pg. 171_](https://2e.aonprd.com/Sources.aspx?ID=118)  
**Perception** +**5**; [darkvision](https://2e.aonprd.com/MonsterAbilities.aspx?ID=12)  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**2**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**9**  
**Str** +4, **Dex** +0, **Con** +3, **Int** -5, **Wis** +1, **Cha** -3  
**Slow** A zombie owlbear is permanently [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) and can't use reactions.

---

**AC** **13**; **Fort** +**5**, **Ref** +**2**, **Will** +**3**  
**HP** 85 ([negative healing](https://2e.aonprd.com/MonsterAbilities.aspx?ID=42)); **Immunities** [death](https://2e.aonprd.com/Traits.aspx?ID=40) effects, [disease](https://2e.aonprd.com/Traits.aspx?ID=46), [mental](https://2e.aonprd.com/Traits.aspx?ID=106), [paralyzed](https://2e.aonprd.com/Conditions.aspx?ID=28), [poison](https://2e.aonprd.com/Traits.aspx?ID=126), [unconscious](https://2e.aonprd.com/Conditions.aspx?ID=38); **Weaknesses** [positive](https://2e.aonprd.com/Traits.aspx?ID=128) 10, slashing 10

---

**Speed** 25 feet  
**Melee** [one-action] talon +**9** [[+4/-1](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d10+7 piercing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Melee** [one-action] beak +**9** [[+4/-1](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+7 piercing**Ground Slam** [two-actions] ([attack](https://2e.aonprd.com/Traits.aspx?ID=15)) **Requirements** The zombie owlbear has a creature [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) or [restrained](https://2e.aonprd.com/Conditions.aspx?ID=33) with its talons; **Effect** The zombie owlbear repeatedly slams the creature into the ground. This deals 1d10+7 bludgeoning damage (DC **17** [basic](https://2e.aonprd.com/Rules.aspx?ID=329) Fortitude save). On a critical failure, the creature is [stunned 1](https://2e.aonprd.com/Conditions.aspx?ID=36), and on a critical success the creature is no longer grabbed or restrained.**Horrifying Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The zombie owlbear unleashes a broken, snarling screech that unnerves those who hear it. Each creature in a 60-foot emanation must attempt a DC **16** Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is frightened 2.  
**Critical Failure** The creature is [fleeing](https://2e.aonprd.com/Conditions.aspx?ID=17) for 1 round and frightened 3.

## All Monsters in "[Zombie](https://2e.aonprd.com/MonsterFamilies.aspx?ID=103)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Zombie, Dirge Piper](https://2e.aonprd.com/Monsters.aspx?ID=2036)|3|
|[Husk Zombie](https://2e.aonprd.com/Monsters.aspx?ID=1919)|2|
|[Plague Zombie](https://2e.aonprd.com/Monsters.aspx?ID=424)|1|
|[Shambler Troop](https://2e.aonprd.com/Monsters.aspx?ID=1376)|4|
|[Zombie, Shock](https://2e.aonprd.com/Monsters.aspx?ID=1985)|6|
|[Sulfur Zombie](https://2e.aonprd.com/Monsters.aspx?ID=1377)|6|
|[Withered](https://2e.aonprd.com/Monsters.aspx?ID=1922)|5|
|[Zombie Brute](https://2e.aonprd.com/Monsters.aspx?ID=425)|2|
|[Zombie Dragon](https://2e.aonprd.com/Monsters.aspx?ID=1378)|9|
|[Zombie Hulk](https://2e.aonprd.com/Monsters.aspx?ID=426)|6|
|[Zombie Lord](https://2e.aonprd.com/Monsters.aspx?ID=1921)|4|
|[Zombie Mammoth](https://2e.aonprd.com/Monsters.aspx?ID=1923)|11|
|[Zombie Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=1920)|3|
|[Zombie Shambler](https://2e.aonprd.com/Monsters.aspx?ID=423)|-1|
|[Zombie Snake](https://2e.aonprd.com/Monsters.aspx?ID=1918)|0|

## [Zombie](https://2e.aonprd.com/MonsterFamilies.aspx?ID=103)

**Source** [_Bestiary pg. 340_](https://2e.aonprd.com/Sources.aspx?ID=2)  
A zombie's only desire is to consume the living. Unthinking and ever-shambling harbingers of death, zombies stop only when they're destroyed.

## Zombie Abilities

You can modify zombies with the following zombie abilities. Most zombies have one of these abilities; If you give a zombie more, you might want to increase its level and adjust its statistics. The DCs use the zombie's level from the [Spell DC and Spell Attack Bonus](https://2e.aonprd.com/Rules.aspx?ID=1020) table.  
**Disgusting Pustules** ([disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie is covered in pustules that rupture when it takes any piercing damage or any critical hit. In either case, adjacent creatures are hit with vile fluid, causing them to become sickened 1 unless they succeed at a Fortitude save.  
**Feast** [two-actions] ([manipulate](https://2e.aonprd.com/Traits.aspx?ID=104)) If the zombie is adjacent to a helpless or unconscious creature, or a deceased creature that died in the past hour, the zombie can feast upon its flesh to heal itself. This restores an amount of Hit Points equal to the zombie's level. If the creature is alive, the zombie deals damage equal to its jaws, flst, or claw damage.  
**Plague-Ridden** ([disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie carries a plague that can create more of its own kind. This functions as the plague zombie's zombie rot, except at stage 5, the victim rises as another of the zombie's type, rather than a plague zombie.  
**Rotting Aura** ([aura](https://2e.aonprd.com/Traits.aspx?ID=206), [disease](https://2e.aonprd.com/Traits.aspx?ID=46), [necromancy](https://2e.aonprd.com/Traits.aspx?ID=117)) The zombie emits an aura of rot and disease that causes wounds to fester and turn sour. Any living creature that starts its turn within 10 feet of the zombie and is not at full Hit Points takes 1d6 damage as its wounds fester. This damage increases by 1d6 for every 6 levels the zombie has. Creatures that take a critical hit from the zombie also take this damage immediately.  
**Unkillable** This zombie is nigh unkillable. The zombie loses its weakness to slashing and gains resistance against all damage equal to its level (minimum 3), and it gains weakness equal to twice its level (minimum 6) to critical hits. Increase the zombie's level by 1 if you give it this ability.

## Additional Monster Abilities

### Bestiary 3

You can modify zombies with the following zombie abilities, in addition to those found on page 340 of the _Bestiary_. Most zombies have one of these abilities; if you give a zombie more, you might want to increase its level and adjust its statistics.  
  
**Ankle Biter** This zombie fights just as well on the ground as it does standing. While [prone](https://2e.aonprd.com/Conditions.aspx?ID=31), the zombie isn't [flat-footed](https://2e.aonprd.com/Conditions.aspx?ID=16), it ignores the status penalty to its attack rolls, and it gains a +2 circumstance bonus to [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) checks to [Trip](https://2e.aonprd.com/Actions.aspx?ID=40). The zombie can also move up to half its Speed when it [Crawls](https://2e.aonprd.com/Actions.aspx?ID=76).  
  
**Persistent Limbs** The first time the zombie is critically hit with a melee or ranged Strike, a limb falls off its body and continues to attack. The limb acts on the zombie's initiative; each round it can Stride up to half the zombie's Speed and make a Strike. The limb uses and contributes to the zombie's multiple attack penalty.  
  
**Putrid Stench** ([aura](https://2e.aonprd.com/Traits.aspx?ID=206), [olfactory](https://2e.aonprd.com/Traits.aspx?ID=246)) 15 feet. The zombie's rotting flesh is particularly malodorous. A creature that enters the area must attempt a Fortitude save. On a failure, the creature is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34), and on a critical failure, the creature also takes a –5-foot status penalty to its Speeds for 1 round. While within the aura, the creature takes a –2 circumstance penalty to saves to recover from the sickened condition. A creature that succeeds at its save is temporarily immune to all zombies' putrid stenches for 1 minute.  
  
**Unholy Speed** The zombie gains a +10 status bonus to all its Speeds

### Book of the Dead

**Infested** The zombie's flesh is infested with swarming vermin. When the zombie is hit with a critical hit or destroyed, the [swarm](https://2e.aonprd.com/Traits.aspx?ID=239) is set free. Its initiative is immediately after the zombie's. If the swarm is 4 or more levels lower than the zombie, it isn't worth XP (and doesn't add its XP to the encounter budget).  
  
**Spitting Zombie** The zombie spits acid as a ranged Strike with a range of 30 feet. This uses the highest attack bonus among the zombie's Strikes and deals 1d12 acid damage per 3 levels of the zombie (or 1d6 acid damage below level 3). On a critical hit, the target also takes 1d4 [persistent acid damage](https://2e.aonprd.com/Conditions.aspx?ID=29) per 3 levels of the zombie. Once used, the zombie must spend 1 action to cough up enough acid to use this ability again.  
  
**Tearing Grapple** The zombies work in groups to rip foes to pieces. Whenever a zombie with this ability successfully [Grapples](https://2e.aonprd.com/Actions.aspx?ID=35) a foe that's already [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) or [restrained](https://2e.aonprd.com/Conditions.aspx?ID=33) by another zombie with this ability, they violently struggle over the poor victim, dealing fist damage (or a similar Strike's damage if the zombie doesn't have a fist Strike). If the grapple is a critical success, the target takes double damage and ceases being grabbed or restrained by any other creatures. If the zombie has the [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18) ability, using Grab deals half its fist Strike damage to the target.

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Creating Zombies

To create a zombie creature, start with a zombie of the appropriate size. Then add any Strikes, Speeds, or other abilities it would gain from its shape. To create a Gargantuan zombie, begin with the zombie hulk, apply the elite adjustments, change its size to Gargantuan, and increase its reach by 5 feet.

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Disposable Legions

With the ancient lich Tar-Baphon now released from his ages-long imprisonment, the undead within his legions have been specifically repurposed. Zombies like the ones seen here fulfill particular roles, and evil necromancers deploy them much like living or intelligent undead troops. Necromancer experiments seek to produce various abilities and mix energies, with horrifying results that doesn't deter their creators.

### ![Sidebar - Treasure and Rewards](https://2e.aonprd.com/Images/Icons/Sidebar_5_TreasureAndRewards.png "Sidebar - Treasure and Rewards")Hoarding Instincts

Though zombies have no use for wealth—indeed, most don't understand the concept in the first place—zombie dragons retain a hint of their innate tendency to hoard. A fresher corpse might guard the hoard it gathered in life (or what remains of it), while a zombie further from life might instead hoard bones, rocks, corpses, or other unusual objects. Understandably, the monetary value of these hoards varies widely

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Mindless Mix-Ups

Zombies try to obey orders, but understanding the words spoken doesn't always mean interpreting them correctly. Examples of misunderstood orders have included the following.

- “Fetch my hat,” leading the zombie to spend hours throwing a hat across a room and retrieving it.
- “Prune these bushes,” resulting in bushes “pruned” entirely, cut off at the root.
- “Let me know if anyone comes to the door,” causing the zombie to go to the door and return to its master.
- “Kill the intruders!” turning zombies raised from a local graveyard against their master, who was not from the area.

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Risen from the Grave

Zombies are often created using unwholesome necromantic rituals. Among the living dead, zombies are most often used as fodder, wearing down defenses and consuming resources before more powerful undead arrive to deal the killing blow. Zombies cannot speak or really even think for themselves, but they can be commanded by other allied undead and powerful necromancers.

### ![Sidebar - Geb](https://2e.aonprd.com/Images/Icons/Sidebar_6_Geb.png "Sidebar - Geb")Symphony of Flesh

Life creates flesh to fulfill its needs, growing it to hunt, consume, and survive. In undeath, the tools of survival can be made into a medium for art. The zombie is the first note in a symphony of dead flesh. Along with skeletons, they are the sturdy, reliable base of any masterpiece and an artist who fails to master these simple tools is not worth notice. One can hear the joyous sounds of the symphony in the low moans and creaking bones of a zombie legion.

### ![Sidebar - Related Creatures](https://2e.aonprd.com/Images/Icons/Sidebar_4_RelatedCreatures.png "Sidebar - Related Creatures")Zombie Animals

Animals, like the [snake](https://2e.aonprd.com/MonsterFamilies.aspx?ID=93), [owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328), and [mammoth](https://2e.aonprd.com/Monsters.aspx?ID=202) found here, can easily turn into zombies. They commonly rise from areas cursed by necromancy rather than being deliberately created. [Risen pets](https://2e.aonprd.com/MonsterFamilies.aspx?ID=309) sometimes develop a fondness for zombies, especially zombies of their former owners. An ordinary zombie can be a suitable companion, capable of petting the risen pet endlessly without the capacity to grow bored.

# Irriseni Owlbear

A cultural symbol for Irrisen, the Irriseni owlbear is particularly well adapted to frosty conditions. These owlbears are larger than their temperate zone counterparts.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 20  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 18  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 15](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=2075&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=2075) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=2075&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=2075&PWL=true)

## [Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)Creature 5

[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Travel Guide pg. 99_](https://2e.aonprd.com/Sources.aspx?ID=141)  
**Perception** +15; [low-light vision](https://2e.aonprd.com/MonsterAbilities.aspx?ID=23), [scent](https://2e.aonprd.com/MonsterAbilities.aspx?ID=33) (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +9, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +16, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +12  
**Str** +6, **Dex** +1, **Con** +5, **Int** -4, **Wis** +3, **Cha** +0

---

**AC** 23; **Fort** +15, **Ref** +9, **Will** +13  
**HP** 85; **Resistances** [cold](https://2e.aonprd.com/Traits.aspx?ID=27) 5

---

**Speed** 25 feet  
**Melee** [one-action] talon +16 [[+12/+8](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170)), **Damage** 1d10+8 piercing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Melee** [one-action] beak +16 [[+11/+6](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+8 piercing**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC 22 Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is frightened 2.  
**Critical Failure** The creature is [fleeing](https://2e.aonprd.com/Conditions.aspx?ID=17) for 1 round and frightened 3.**Gnaw** [one-action] **Requirements** The owlbear has a creature [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC 24 Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is sickened 1 and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains sickened.**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.

## All Monsters in "[Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)|5|
|[Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)|4|

## [Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)

**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech only seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.

# Irriseni Owlbear (Prof w/o Level)

A cultural symbol for Irrisen, the Irriseni owlbear is particularly well adapted to frosty conditions. These owlbears are larger than their temperate zone counterparts.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 20  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 18  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 15](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=2075&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=2075) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=2075&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=2075&PWL=true)

## [Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)Creature 5

[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Travel Guide pg. 99_](https://2e.aonprd.com/Sources.aspx?ID=141)  
**Perception** +**10**; [low-light vision](https://2e.aonprd.com/MonsterAbilities.aspx?ID=23), [scent](https://2e.aonprd.com/MonsterAbilities.aspx?ID=33) (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**4**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**11**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**7**  
**Str** +6, **Dex** +1, **Con** +5, **Int** -4, **Wis** +3, **Cha** +0

---

**AC** **18**; **Fort** +**10**, **Ref** +**4**, **Will** +**8**  
**HP** 85; **Resistances** [cold](https://2e.aonprd.com/Traits.aspx?ID=27) 5

---

**Speed** 25 feet  
**Melee** [one-action] talon +**11** [[+7/+3](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170)), **Damage** 1d10+8 piercing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Melee** [one-action] beak +**11** [[+6/+1](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d12+8 piercing**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC **17** Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is frightened 2.  
**Critical Failure** The creature is [fleeing](https://2e.aonprd.com/Conditions.aspx?ID=17) for 1 round and frightened 3.**Gnaw** [one-action] **Requirements** The owlbear has a creature [grabbed](https://2e.aonprd.com/Conditions.aspx?ID=20) with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC **19** Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is sickened 1 and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains sickened.**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.

## All Monsters in "[Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)"

|   |   |
|---|---|
|**Name**|**Level**|
|[Irriseni Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2075)|5|
|[Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)|4|

## [Owlbear](https://2e.aonprd.com/MonsterFamilies.aspx?ID=320)

**Source** [_Bestiary pg. 259_](https://2e.aonprd.com/Sources.aspx?ID=2)  
With the body of a powerful brown bear and the keen senses of an owl, the owlbear is a dangerous territorial predator, fearlessly attacking any creature that strays into its domain. Those who run afoul of an owlbear hear its terrifying screech only seconds before the massive creature is upon them, ripping them apart with deadly talons and a powerful beak.

# Winged Owlbear

This creature did not include a description.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 38  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 36  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 33](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=2355&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=2355) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=2355&Weak=true) 

[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=2355&PWL=true)

## [Winged Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2355)Creature 18

[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Gargantuan](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Kingmaker Adventure Path pg. 451_](https://2e.aonprd.com/Sources.aspx?ID=150)  
Variant [owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)  
**Perception** +32; [low-light vision](https://2e.aonprd.com/Monsters.aspx?ID=1969), [scent](https://2e.aonprd.com/MonsterAbilities.aspx?ID=33) (imprecise) 30 feet  
**Languages** [Sylvan](https://2e.aonprd.com/Languages.aspx?ID=10); (can't speak any language)  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +31, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +35, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +31  
**Str** +9, **Dex** +5, **Con** +6, **Int** -2, **Wis** +5, **Cha** +4

---

**AC** 41; **Fort** +32, **Ref** +30, **Will** +30  
**HP** 380

---

**Speed** 30 feet, fly 50 feet  
**Melee** [one-action] beak +35 [[+30/+25](https://2e.aonprd.com/Rules.aspx?ID=322)] ([reach 10 feet](https://2e.aonprd.com/Traits.aspx?ID=192)), **Damage** 3d12+17 piercing plus 1d12 bleed**Melee** [one-action] talon +35 [[+31/+27](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [reach 20 feet](https://2e.aonprd.com/Traits.aspx?ID=192)), **Damage** 3d10+17 slashing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC 40 Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is [frightened 2](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Critical Failure** The creature is fleeing for 1 round and [frightened 3](https://2e.aonprd.com/Conditions.aspx?ID=19).**Gnaw** [one-action] **Requirements** The owlbear has a creature grabbed with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC 40 Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34) and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains [sickened](https://2e.aonprd.com/Conditions.aspx?ID=34).
**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.

# Winged Owlbear (Prof w/o Level)

This creature did not include a description.  
  
**[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 38  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 36  
](https://2e.aonprd.com/Rules.aspx?ID=563)**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 33](https://2e.aonprd.com/Rules.aspx?ID=563)

## [](https://2e.aonprd.com/Rules.aspx?ID=563)[**Elite**](https://2e.aonprd.com/Monsters.aspx?ID=2355&Elite=true) | [**Normal**](https://2e.aonprd.com/Monsters.aspx?ID=2355) | [**Weak**](https://2e.aonprd.com/Monsters.aspx?ID=2355&Weak=true)  
[**Proficiency without Level**](https://2e.aonprd.com/Monsters.aspx?ID=2355&PWL=true)

## [Winged Owlbear](https://2e.aonprd.com/Monsters.aspx?ID=2355)Creature 18

[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Gargantuan](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Kingmaker Adventure Path pg. 451_](https://2e.aonprd.com/Sources.aspx?ID=150)  
Variant [owlbear](https://2e.aonprd.com/Monsters.aspx?ID=328)  
**Perception** +**14**; [low-light vision](https://2e.aonprd.com/Monsters.aspx?ID=1969), [scent](https://2e.aonprd.com/MonsterAbilities.aspx?ID=33) (imprecise) 30 feet  
**Languages** [Sylvan](https://2e.aonprd.com/Languages.aspx?ID=10); (can't speak any language)  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**13**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**17**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**13**  
**Str** +9, **Dex** +5, **Con** +6, **Int** -2, **Wis** +5, **Cha** +4

---

**AC** **23**; **Fort** +**14**, **Ref** +**12**, **Will** +**12**  
**HP** 380

---

**Speed** 30 feet, fly 50 feet  
**Melee** [one-action] beak +**17** [[+12/+7](https://2e.aonprd.com/Rules.aspx?ID=322)] ([reach 10 feet](https://2e.aonprd.com/Traits.aspx?ID=192)), **Damage** 3d12+17 piercing plus 1d12 bleed**Melee** [one-action] talon +**17** [[+13/+9](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [reach 20 feet](https://2e.aonprd.com/Traits.aspx?ID=192)), **Damage** 3d10+17 slashing plus [Grab](https://2e.aonprd.com/MonsterAbilities.aspx?ID=18)**Bloodcurdling Screech** [one-action] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear unleashes a loud screech that terrifies its prey. Each creature in an 80-foot emanation must attempt a DC **22** Will save. Regardless of the result, creatures are temporarily immune for 1 minute.  
**Critical Success** The creature is unaffected.  
**Success** The creature is [frightened 1](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Failure** The creature is [frightened 2](https://2e.aonprd.com/Conditions.aspx?ID=19).  
**Critical Failure** The creature is fleeing for 1 round and [frightened 3](https://2e.aonprd.com/Conditions.aspx?ID=19).**Gnaw** [one-action] **Requirements** The owlbear has a creature grabbed with its talons. **Effect** The owlbear attempts to disembowel the creature with a beak Strike. If the Strike hits, the target must attempt a DC **22** Will save.  
**Critical Success** The target is unaffected.  
**Success** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34).  
**Failure** The target is [sickened 1](https://2e.aonprd.com/Conditions.aspx?ID=34) and [slowed 1](https://2e.aonprd.com/Conditions.aspx?ID=35) as long as it remains [sickened](https://2e.aonprd.com/Conditions.aspx?ID=34).**Screeching Advance** [two-actions] ([auditory](https://2e.aonprd.com/Traits.aspx?ID=16), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [fear](https://2e.aonprd.com/Traits.aspx?ID=68), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) The owlbear makes a Bloodcurdling Screech and Strides twice. All creatures within 80 feet of the owlbear at any point during this movement are subjected to the effects of Bloodcurdling Screech.