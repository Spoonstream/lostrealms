**Source** [_Gamemastery Guide pg. 232_](https://2e.aonprd.com/Sources.aspx?ID=22)  
Larger societies rely on those with the authority and the ability to interpret and enforce laws. In good-aligned societies, these officials carry out their duties fairly. In neutral and evil ones, these officials can be harsh and cruel (with an altered alignment to reflect this), imposing severe punishments on those who can't pay for mercy.

### Members

[Archer Sentry](https://2e.aonprd.com/NPCs.aspx?ID=934) (Creature 2), [Barrister](https://2e.aonprd.com/NPCs.aspx?ID=932) (Creature -1), [Captain of the Guard](https://2e.aonprd.com/NPCs.aspx?ID=937) (Creature 6), [Executioner](https://2e.aonprd.com/NPCs.aspx?ID=938) (Creature 6), [Guard](https://2e.aonprd.com/NPCs.aspx?ID=933) (Creature 1), [Jailer](https://2e.aonprd.com/NPCs.aspx?ID=935) (Creature 3), [Watch Officer](https://2e.aonprd.com/NPCs.aspx?ID=936) (Creature 3)

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Deploying The Watch

If no guard is present, it takes at least 1–2 rounds for a civilian to find a guard to sound an alarm whistle. If a guard was on the scene, they sound the alarm immediately. Reinforcements typically arrive 2–3 rounds later.

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Jailbreak!

If a PC or ally gets imprisoned, the group might plot a jailbreak. For a complex jail or penitentiary, this might require use of the [infiltration](https://2e.aonprd.com/Rules.aspx?ID=1221) subsystem. With a smaller town or city jail with a simple structure and small staff, it could require just a bit of force. The jailbreak might just be the beginning, leading to additional adventure!

### ![Sidebar - Advice and Rules](https://2e.aonprd.com/Images/Icons/Sidebar_1_AdviceAndRules.png "Sidebar - Advice and Rules")Raise The Alarm!

In a settlement with an alarm, brawls or other major disruptions trigger an alarm 1 round after the watch is alerted. Guards start to arrive after about 5 rounds, usually in patrols of 2 or 3 members, with larger groups of 8–12 near important locations.

### ![Sidebar - Additional Lore](https://2e.aonprd.com/Images/Icons/Sidebar_2_AdditionalLore.png "Sidebar - Additional Lore")Unusual Misdemeanors

- Altering the weather without a permit
- Consuming (or refusing to consume) intoxicating substances on celebration days
- Failing to clean up after animal companions
- Flying within city limits
- Selling potions without a license

>  ## [Guard](https://2e.aonprd.com/NPCs.aspx?ID=933)Creature 1
>  **[Recall Knowledge - Humanoid](https://2e.aonprd.com/Rules.aspx?ID=563) ([Society](https://2e.aonprd.com/Skills.aspx?ID=14))**: DC 14  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 12](https://2e.aonprd.com/Rules.aspx?ID=563)**
[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 9](https://2e.aonprd.com/Rules.aspx?ID=563)
>
>[LN](https://2e.aonprd.com/Rules.aspx?ID=95) [Medium](https://2e.aonprd.com/Rules.aspx?ID=445) [Human](https://2e.aonprd.com/Traits.aspx?ID=90) [Humanoid](https://2e.aonprd.com/Traits.aspx?ID=91)
**Source** [_Gamemastery Guide pg. 232_](https://2e.aonprd.com/Sources.aspx?ID=22)  
**Perception** +**6**; (8 to find concealed objects)  
**Languages** [Common](https://2e.aonprd.com/Languages.aspx?ID=1)  
**Skills** [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**6**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**4**, [Legal Lore](https://2e.aonprd.com/Skills.aspx?ID=8) +**2**  
**Str** +4, **Dex** +2, **Con** +2, **Int** +0, **Wis** +2, **Cha** -1  
**Items** [club](https://2e.aonprd.com/Weapons.aspx?ID=2), [crossbow (10 bolts)](https://2e.aonprd.com/Weapons.aspx?ID=67), [dagger](https://2e.aonprd.com/Weapons.aspx?ID=3), [sap](https://2e.aonprd.com/Weapons.aspx?ID=37), [scale mail](https://2e.aonprd.com/Armor.aspx?ID=8), [signal whistle](https://2e.aonprd.com/Equipment.aspx?ID=50)
>**AC** **15/17/19**; **Fort** **+4/+6/+8**, **Ref** **+2/+4/+6**, **Will** **+2/+4/+6**  
**HP** 10/20/30  
**[Attack of Opportunity](https://2e.aonprd.com/MonsterAbilities.aspx?ID=3) [reaction]**
>
>**Speed** 25 feet  
**Melee** [one-action] club +**6/+8/+10** [[+3/+2](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d6+2/1d6+4/1d6+6 bludgeoning
**Melee** [one-action] sap +**6/8** [[+4/+0](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [nonlethal](https://2e.aonprd.com/Traits.aspx?ID=188)), **Damage** 1d6+2/1d6+4/1d6+6 bludgeoning
**Ranged** [one-action] crossbow +**4** [[+1/+4](https://2e.aonprd.com/Rules.aspx?ID=322)] ([range increment 120 feet](https://2e.aonprd.com/Traits.aspx?ID=248), [reload 1](https://2e.aonprd.com/Traits.aspx?ID=254)), **Damage** 1d8-2/1d8/1d8+2 piercing
**Ranged** [one-action] club +**6** [[+1/+4](https://2e.aonprd.com/Rules.aspx?ID=322)] ([thrown 10 feet](https://2e.aonprd.com/Traits.aspx?ID=195)), **Damage** 1d6+2/1d6+4/1d6+6 bludgeoning


## Archer Sentry (Creature 2)


>## [Archer Sentry](https://2e.aonprd.com/NPCs.aspx?ID=934)(Creature 2)
Archer sentries slightly outrank the rank-and-file guards, taking positions on walls, garrisons, and other important locations where they can stay out of the fray and pick off criminals or assailants.  
>
>**[Recall Knowledge - Humanoid](https://2e.aonprd.com/Rules.aspx?ID=563) ([Society](https://2e.aonprd.com/Skills.aspx?ID=14))**: DC 16  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 14 ](https://2e.aonprd.com/Rules.aspx?ID=563)
**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 11](https://2e.aonprd.com/Rules.aspx?ID=563)
>
> [LN](https://2e.aonprd.com/Rules.aspx?ID=95) [Medium](https://2e.aonprd.com/Rules.aspx?ID=445) [Human](https://2e.aonprd.com/Traits.aspx?ID=90) [Humanoid](https://2e.aonprd.com/Traits.aspx?ID=91)   
**Source** [_Gamemastery Guide pg. 233_](https://2e.aonprd.com/Sources.aspx?ID=22)  
**Perception** +11  
**Languages** [Common](https://2e.aonprd.com/Languages.aspx?ID=1)  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +8, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +6, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +4, [Legal Lore](https://2e.aonprd.com/Skills.aspx?ID=8) +4  
**Str** +2, **Dex** +4, **Con** +1, **Int** +0, **Wis** +3, **Cha** +0  
**Items** [composite longbow (100 arrows)](https://2e.aonprd.com/Weapons.aspx?ID=74), [leather armor](https://2e.aonprd.com/Armor.aspx?ID=4), [shortsword](https://2e.aonprd.com/Weapons.aspx?ID=43), [signal whistle](https://2e.aonprd.com/Equipment.aspx?ID=50)
>**AC** 19; **Fort** +7, **Ref** +10, **Will** +7  
**HP** 30
>
>**Speed** 25 feet  
**Melee** [one-action] shortsword +10 [[+6/+2](https://2e.aonprd.com/Rules.aspx?ID=322)] ([agile](https://2e.aonprd.com/Traits.aspx?ID=170), [finesse](https://2e.aonprd.com/Traits.aspx?ID=179), [versatile P](https://2e.aonprd.com/Traits.aspx?ID=200)), **Damage** 1d6+3 slashing
**Ranged** [one-action] composite longbow +10 [[+5/+0](https://2e.aonprd.com/Rules.aspx?ID=322)] ([deadly 1d10](https://2e.aonprd.com/Traits.aspx?ID=174), [range increment 100 feet](https://2e.aonprd.com/Traits.aspx?ID=248), [reload 0](https://2e.aonprd.com/Traits.aspx?ID=254), [volley 30 feet](https://2e.aonprd.com/Traits.aspx?ID=201)), **Damage** 1d8+2 piercing
**Sentry's Aim** [two-actions] ([concentrate](https://2e.aonprd.com/Traits.aspx?ID=32)) The archer sentry aims carefully and fires. They make a ranged weapon Strike with a +1 circumstance bonus. The Strike ignores the [concealed](https://2e.aonprd.com/Conditions.aspx?ID=4) condition, [lesser cover, and standard cover, and reduces greater cover to standard cover](https://2e.aonprd.com/Rules.aspx?ID=459).


## Watch Officer (Creature 3)

>  ## [Watch Officer](https://2e.aonprd.com/NPCs.aspx?ID=936)Creature 3
>  Watch officers are assigned to a certain area within a city or community. Often leading a small team of lower-ranking guards, they patrol those areas to maintain order and enforce laws. Watch officers get the job done, though their methods are not always gentle or kind. Because the watch officer is responsible to their superiors for their area, they sometimes need to make tough decisions between justice and effectiveness.  
>  
>  **[Recall Knowledge - Humanoid](https://2e.aonprd.com/Rules.aspx?ID=563) ([Society](https://2e.aonprd.com/Skills.aspx?ID=14))**: DC 18  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 16 ](https://2e.aonprd.com/Rules.aspx?ID=563)
**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 13](https://2e.aonprd.com/Rules.aspx?ID=563)
>
>**Source** [_Gamemastery Guide pg. 234_](https://2e.aonprd.com/Sources.aspx?ID=22)  
**Perception** +**5**; (9 to [Sense Motive](https://2e.aonprd.com/Actions.aspx?ID=85))  
**Languages** [Common](https://2e.aonprd.com/Languages.aspx?ID=1)  
**Skills** [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**8**, [Diplomacy](https://2e.aonprd.com/Skills.aspx?ID=6) +**3**, [Intimidation](https://2e.aonprd.com/Skills.aspx?ID=7) +**6**, [Legal Lore](https://2e.aonprd.com/Skills.aspx?ID=8) +**4**, [Society](https://2e.aonprd.com/Skills.aspx?ID=14) +**2**  
**Str** +4, **Dex** +1, **Con** +3, **Int** +0, **Wis** +1, **Cha** +1  
**Items** [breastplate](https://2e.aonprd.com/Armor.aspx?ID=10), [crossbow (20 bolts)](https://2e.aonprd.com/Weapons.aspx?ID=67), [dagger](https://2e.aonprd.com/Weapons.aspx?ID=3), [signal whistle](https://2e.aonprd.com/Equipment.aspx?ID=50), [steel shield (Hardness 5, 20 HP, BT 10)](https://2e.aonprd.com/Shields.aspx?ID=3), [warhammer](https://2e.aonprd.com/Equipment.aspx?ID=24)
>**AC** **17** (**19** with shield raised); **Fort** +**7**, **Ref** +**3**, **Will** +**5**  
**HP** 45  
**Air of Authority** ([aura](https://2e.aonprd.com/Traits.aspx?ID=206), [emotion](https://2e.aonprd.com/Traits.aspx?ID=60), [mental](https://2e.aonprd.com/Traits.aspx?ID=106)) 10 feet. Creatures in the aura who are the same or lower level than the watch officer take a -2 status penalty to their Will DC against the watch officer's attempts to [Coerce](https://2e.aonprd.com/Actions.aspx?ID=52) or [Demoralize](https://2e.aonprd.com/Actions.aspx?ID=53) them.
>
>**Bravery** When the watch officer rolls a success on a Will save against a [fear](https://2e.aonprd.com/Traits.aspx?ID=68) effect, they get a critical success instead. In addition, any time they gain the [frightened](https://2e.aonprd.com/Conditions.aspx?ID=19) condition, reduce its value by 1.
>
**[Attack of Opportunity](https://2e.aonprd.com/MonsterAbilities.aspx?ID=3) [reaction]**
**[Shield Block](https://2e.aonprd.com/MonsterAbilities.aspx?ID=32) [reaction]**
>
>**Speed** 25 feet  
**Melee** [one-action] warhammer +**10** [[+5/+0](https://2e.aonprd.com/Rules.aspx?ID=322)] ([shove](https://2e.aonprd.com/Traits.aspx?ID=193)), **Damage** 1d8+7 bludgeoning
**Ranged** [one-action] crossbow +**7** [[+2/-3](https://2e.aonprd.com/Rules.aspx?ID=322)] ([range increment 120 feet](https://2e.aonprd.com/Traits.aspx?ID=248), [reload 1](https://2e.aonprd.com/Traits.aspx?ID=254)), **Damage** 1d8+3 piercing
**Sudden Charge** [two-actions] **Frequency** once per round; **Effect** The watch officer Strides twice. If they end their movement within melee reach of at least one enemy, they can make a melee Strike against that enemy.



