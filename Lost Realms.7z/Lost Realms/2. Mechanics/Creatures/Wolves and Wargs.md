

# Wolf 

**Source** [_Bestiary pg. 334_](https://2e.aonprd.com/Sources.aspx?ID=2)  
Wolves roam forests, hills, and other wild lands, where they hunt in packs to beleaguer and surround their prey before going in for the kill. Like most predatory animals, wolves prefer to attack the weakest or most vulnerable prey they can find.

### ![Sidebar - Related Creatures](https://2e.aonprd.com/Images/Icons/Sidebar_4_RelatedCreatures.png "Sidebar - Related Creatures")Wolf Packs

Wolf packs claim and defend large swaths of territory, which they regularly patrol in search of both prey and competitors. It takes a pack roughly 10 days to cover the entire breadth of its territory, which can stretch for miles in any direction but usually adheres to natural terrain. Wolves keep claim over their territories by marking trees with their scent and howling to keep other packs away. If these warnings prove insufficient to drive off potential competitors, the pack attacks the intruders directly


# Wolf (Creature 1)

  



> **[Recall Knowledge - Animal](https://2e.aonprd.com/Rules.aspx?ID=563) ([Nature](https://2e.aonprd.com/Skills.aspx?ID=10))**: DC 15  
**[Unspecific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 13  ](https://2e.aonprd.com/Rules.aspx?ID=563)
**[Specific Lore](https://2e.aonprd.com/Rules.aspx?ID=563)**[: DC 10](https://2e.aonprd.com/Rules.aspx?ID=563)
>[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Medium](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Bestiary pg. 334_](https://2e.aonprd.com/Sources.aspx?ID=2)  
**Perception** +**6**; low-light vision, scent (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**6**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**4**, [Stealth](https://2e.aonprd.com/Skills.aspx?ID=15) +**6**, [Survival](https://2e.aonprd.com/Skills.aspx?ID=16) +**6**  
**Str** +2, **Dex** +4, **Con** +1, **Int** -4, **Wis** +2, **Cha** -2
>**AC** **14**; **Fort** +**5**, **Ref** +**8**, **Will** +**4**  
**HP** 14/24
**Speed** 35 feet  
**Melee** [one-action] jaws **+6/+8** [[+1/-4,+3/-2](https://2e.aonprd.com/Rules.aspx?ID=322)], **Damage** 1d6/1d6+2 piercing plus Knockdown
**Pack Attack** The wolf's Strikes deal 1d4 extra damage to creatures within reach of at least two of the wolf's allies.
>


# Dire Wolf (Creature 3)

> # [Dire Wolf](https://2e.aonprd.com/Monsters.aspx?ID=416)Creature 3
[N](https://2e.aonprd.com/Rules.aspx?ID=95) [Large](https://2e.aonprd.com/Rules.aspx?ID=445) [Animal](https://2e.aonprd.com/Traits.aspx?ID=9)   
**Source** [_Bestiary pg. 334_](https://2e.aonprd.com/Sources.aspx?ID=2)  
**Perception** +**7**; low-light vision, scent (imprecise) 30 feet  
**Skills** [Acrobatics](https://2e.aonprd.com/Skills.aspx?ID=1) +**5**, [Athletics](https://2e.aonprd.com/Skills.aspx?ID=3) +**9**, [Stealth](https://2e.aonprd.com/Skills.aspx?ID=15) +**5**, [Survival](https://2e.aonprd.com/Skills.aspx?ID=16) +**7**  
**Str** +5, **Dex** +3, **Con** +4, **Int** -4, **Wis** +3, **Cha** -2
>**AC** **15**; **Fort** +**8**, **Ref** +**5**, **Will** +**5**  
**HP** 50  
**Buck** [reaction] DC **17**
>**Speed** 35 feet  
**Melee** [one-action] jaws +**9** [[+4/-1](https://2e.aonprd.com/Rules.aspx?ID=322)] ([reach 10 feet](https://2e.aonprd.com/Traits.aspx?ID=192)), **Damage** 1d10+5 piercing plus Knockdown or Grab
**Pack Attack** The dire wolf's Strikes deal 1d6 extra damage to creatures within reach of at least two of the wolf's allies.
**Worry** [one-action] ([attack](https://2e.aonprd.com/Traits.aspx?ID=15)) **Requirements** The dire wolf has a creature grabbed with its jaws. **Effect** The dire wolf fiercely shakes the grabbed creature with its teeth, dealing 1d10+2 damage (DC **17** basic Fortitude save).
