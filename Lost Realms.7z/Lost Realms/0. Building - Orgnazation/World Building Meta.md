
# Concepts
## Themes, Mood and Inspirations

## Core Concepts


## Design Approaches

### Language



# General Overview

### Setting Description

### History

### Theme Reinforcing Concepts




# Descriptions by Topic

### The Nature of Magic

### The Eternals

### Dragons

### Fantasy Races

### The Guilds

### The "Blight"

# Presentation

### Aesthetics

### Poetry Layer


# Copy Pasta (for revision)
Concepts (What the world is about)

- ##### Externalities
- #### Climate Change
- Compromise ()
- Liberation Theology - internal revolution ()

Overview
The world is on the brink of a catastrophe. The art of artificing is causing an imbalance in the nature of magic that will bring potentially world ending destruction. The Artificer's guild (or just The Guild) has revolutionized the world, and has conquered the world, through it's economy and influence. 

The continent of Ennaryn, once the home of the first civilization, is left to ruin. The corruption running rampant, and a long dark age changing it's landscape, both physical and political. The Guild has conquered the most desired fringes of it's continent but has left the it's heart untamed, using it as a sacrifice zone, fueling civil strife and sending undesirables into it.

Historical Ages

Creation
Rise of Dragon kind
The first societies
Birth of the Divine order
The Divine Wars
The Sundering.


Discovery of the Void
Discovery that magical artificing, the art of which the modern society is built, and the guild has gain it's power, is destroying the world.

A major endeavor is taken to reestablish a colony on the continent of Ennaryn, with the goal of trying to find a way to undo the rift. 

The guild co-opts the effort and the new colony's are quickly mired in civil strife, wars between old forgotten kingdoms and the oppressive rulership of the guild. 

(its sorta like now...we are fucked because the effort to do something about climate change was completely co-opted by capitalism)


Inspirations
Black Sails
Dark Water
Midnight
The Witcher (Netflix Series)
The Cover art from Eye of the World (the first one)
7th seas
Willow
Blades in the Dark
Death Gate Cycle



- magic shapes around people's ideas, changes them, they grow in power, change things around them, eventually ascend, they are revered, which slows magics change upon them. When they die they dissipate and are consumed into the consciousness.
- The Guild was a bunch of fucked up people living in a fucked up time that ordered things out of neccassity. their ancestors payed the costs for that. 
- normal technology happens (before magic) then magic introduced, and magic technology arises out of that.
- People in the "Zone" live in inferior more medieval standards. the closer to El Dorado, the more dark age, but not because of circumstance the reasons are because of society influences. We create the other. 
- Races (fantasy) existed because they were strong social ideas that were impressed upon them. The more free of those ideas they became the less the impact...although heritage exists. Some still exist...
	- isreal palestine conflict but the oppressed are "Morokai" pretty much orcs. same history and some blending but pretty much same political situation and history. \
- Magic Towers were a defense system for empire...empire falls after (Soviet Union Collapses) and then the Towers are turned inward keeping everyone in the zone. 


Thematic Concept: 
	It's not about saving the world. It's about holding on to hope.
	It's not about saving the innocent, its about searching for innocence.
	It's not about defeating the enemy, it's about conquering your fear.

3 Core Design Philosophy's
	1)Action Matters, Story Matters More
			The characters will want to do things. Those "things" should always serve the immediate narrative (fiction first mechanics) but also serve to build upon their own personal Narrative
	2) Make the players invest in the consequences and then raise the stakes.
	3) Many choices in wrapped up in a simple sets of rules. 


Game Synopsis

Players take on the role of characters adventuring in the dangerous and ancient  continent of Enarryn. Once the birthplace of civilization millennia have marked the ruined continent. It is a land on the fringes, under constant siege of the colonial forces of the Guild, old orders and conspiracies' that seek vengeance for past wrongs, rebellions and revolutionaries, adventures seeking fame and fortune, criminals exploring the weak and vulnerable, and those lost souls seeking truth at the ends of the map. 

Underneath all of that is the looming dread of a dreaded fate. What distinguishes the characters in this story from any other inhabitant of this world, is that they sense an the coming of a storm, or a calamity. They don't know how long, what will happen, or what the consequences will be. 


REVISE ABOVE...THE ETERNALS ARE DARK GODS THAT PRESIDE OVER THE GUILD AND ARE CAUSING CLIMATE CHANGE....


Unique Mechanics and Features

1)  The Calamity Clock
	1) Each character has a progenerated (random?) fate that will be given to them. This is the "sign" that they were born under - and serves to give the player a hint of some upcoming event. Collectively all of the characters fate signs will help the GM with the event.
	2) During the game the clock will be present for all players to see and will count down. The amount that the clock. The scale of the event and the time until its occurrence is determined by the players. 
2) 3 Difference types of player currencies
	1) Personal Points - used to fuel personal abilities that are offensive or allow the player to do things without increasing GM Plot Dice.
	2) Team Points: Used to provide dice pool bonuses, power body gaurd effects - these can also provide a personal benefit when given. 
	3)  Defensive Points - Allow the player to resist or reduce the consequences of GM outcomes
3) 3 Character advancement paths
	1) Drives
	2) Touchstones
	3) Background (needs a better term)


Game Loop:
Need's inform motivation, motivation informs choice, choices inform consequences, consequences inform new sets of the needs. 




