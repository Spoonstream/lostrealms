
Root Concept (at a symbolic level):
- Setting is about climate change
- Climate change is caused by externalities 
- Externalities are consequences that the product of the systems of material organization rooted in capitalism
	- Those consequences are paid by others that do not profit from those systems of accumalation.
	- The motivation behind such is development and growth, which is rooted in the need for power and control over the material.
- This is blind adherance to the "how" reproductive processes can be sustainable (reduced to the perspective of the individual)
- The more we have sought the "how", the farther we have gotten away from the "why", which is simply "to live".
	- Living is defined by death, the limitation of time. This is a paradox because to live is also to thrive in spite of death. 
- 

[[The Magisters]]: is older than the guild system and what allowed the guild system to exist. They were tasked to enforce and regulate magic users andd they picked sides (or perphaps the treaty exclude "merchants" or something)

[[Gateways]]: Two era's of gateway construction. Imperial and Post Imperial. Thaelos came to understand that the gateways were causing tears in the viel. He Build the boundary to protect the rest of the empire from the most powerful fonts in the event of tears beginning to manifest. The Gateway in [[Mekh'Reban]]  

Boundary: Was one piece of a network of magical shields to prevent corruption from the veil from spreading. The network of powerful loci that spread across enarynn are spreading dissonant energies and seeping energies from the [[Aetherium]]. 

The Sundering was caused by the First people. 
The First People created the other primordial forces by virtue of their existence. 
Each was compelled to converge in a violent union which created the world. 
The First people created the Eternals out to the embodied emergent mortals and elevated them.
The sundering was the product of the first people leaving the world behind on its own. 
Each of the primordial forces are attempting to undo or protect the veil. 
They act through agents. 
