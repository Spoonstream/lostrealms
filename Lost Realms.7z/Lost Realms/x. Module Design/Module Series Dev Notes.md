
Brainstorm
- 6 adventures
- Needs to have a "How to use this section"
- Needs to work with and without profiecency without level.
- Needs to have a understandable framework behind how they are created. 
	- Almost like a how to GM section but does it better because of examples.
- Options for multiple paths
- Notated points where people can include their own. 
- Handouts
- Flowcharts
- Tracking aid for knowledge checks 
- Everything is referencable. 
- No referencing outside the book. 




Ideas

Shoemakers...it would be a good way to show the distinction between economic systems. Shoe's are both made artificiers items and normal mundane. 