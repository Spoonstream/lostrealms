---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Introduce a Need to get to Cross the Boundary ^w2DRPDAR

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.18",
	"elements": [
		{
			"type": "diamond",
			"version": 748,
			"versionNonce": 1256818283,
			"isDeleted": false,
			"id": "MZBhjrqgxdBcCupAXF5V6",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -206.02272727272702,
			"y": -1014.8998579545455,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#6a7051",
			"width": 282,
			"height": 270,
			"seed": 1001336360,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "w2DRPDAR"
				},
				{
					"id": "N382cTwh-dxVcP8hE2pwy",
					"type": "arrow"
				}
			],
			"updated": 1703640629984,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 327,
			"versionNonce": 207847691,
			"isDeleted": false,
			"id": "w2DRPDAR",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -129.52272727272702,
			"y": -929.8998579545455,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 129,
			"height": 100,
			"seed": 1482192936,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1703640629984,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Introduce a\nNeed to get\nto Cross the\nBoundary",
			"rawText": "Introduce a Need to get to Cross the Boundary",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "MZBhjrqgxdBcCupAXF5V6",
			"originalText": "Introduce a Need to get to Cross the Boundary",
			"lineHeight": 1.25,
			"baseline": 93
		},
		{
			"type": "ellipse",
			"version": 612,
			"versionNonce": 309008587,
			"isDeleted": false,
			"id": "Fq4RLqCvLl0Xvk3yie56b",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -481.75,
			"y": 11.5546875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#a5d8ff",
			"width": 217,
			"height": 202,
			"seed": 2016046120,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "0XYyJhzyTS6CFHzpmlHSI",
					"type": "arrow"
				},
				{
					"id": "p0TY-9ZLDJH9xDemy-pbL",
					"type": "arrow"
				}
			],
			"updated": 1703640692576,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 425,
			"versionNonce": 1450351051,
			"isDeleted": false,
			"id": "RctvImppAUYYKN5WEw_gP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 166.25,
			"y": 6.5546875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#a5d8ff",
			"width": 210,
			"height": 203,
			"seed": 1941647192,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "ySgvwhSiSM9mNlF9reXC9",
					"type": "arrow"
				},
				{
					"id": "C8_-PDL3V7zVYOEvoWyCK",
					"type": "arrow"
				}
			],
			"updated": 1703640700129,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 414,
			"versionNonce": 1399885605,
			"isDeleted": false,
			"id": "vm0OJZloSCGZJ-NNQehDC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -149.75,
			"y": 4.5546875,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#a5d8ff",
			"width": 203,
			"height": 207,
			"seed": 2067454296,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "YmbB9kJz50t6PG0-hmwsP",
					"type": "arrow"
				},
				{
					"id": "JY4H-_crTfdUtAJ7JfEkz",
					"type": "arrow"
				}
			],
			"updated": 1703640696596,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 251,
			"versionNonce": 728161605,
			"isDeleted": false,
			"id": "0nPT6TFRBB61_p4oOMDbv",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -196.65909090909076,
			"y": -177.0816761363635,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffec99",
			"width": 293,
			"height": 118,
			"seed": 158419800,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "RSHFh-voxygHdRssCis0-",
					"type": "arrow"
				},
				{
					"id": "0XYyJhzyTS6CFHzpmlHSI",
					"type": "arrow"
				},
				{
					"id": "YmbB9kJz50t6PG0-hmwsP",
					"type": "arrow"
				},
				{
					"id": "ySgvwhSiSM9mNlF9reXC9",
					"type": "arrow"
				}
			],
			"updated": 1703640676264,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 315,
			"versionNonce": 204006155,
			"isDeleted": false,
			"id": "Jux3vhwI8I6UjxBYjrlKP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -214.93181818181802,
			"y": 348.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffec99",
			"width": 334,
			"height": 139,
			"seed": 650555224,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [
				{
					"id": "p0TY-9ZLDJH9xDemy-pbL",
					"type": "arrow"
				},
				{
					"id": "C8_-PDL3V7zVYOEvoWyCK",
					"type": "arrow"
				}
			],
			"updated": 1703640700129,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 165,
			"versionNonce": 1183208997,
			"isDeleted": false,
			"id": "CuASUEBrP--NRXcvJjPji",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -488.75,
			"y": 582.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 2101034328,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 257,
			"versionNonce": 206391979,
			"isDeleted": false,
			"id": "DK3_M8ltIXCjidYfnXOqE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -156.25,
			"y": 577.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 1898939944,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 235,
			"versionNonce": 570575237,
			"isDeleted": false,
			"id": "hjOQKDioGWgxiJXkEMDZC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 158.75,
			"y": 576.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 2135609688,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 192,
			"versionNonce": 759479627,
			"isDeleted": false,
			"id": "-BWce8KT5CJnCqzFKHAL3",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -518.25,
			"y": 1087.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 156077352,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 222,
			"versionNonce": 1147719909,
			"isDeleted": false,
			"id": "AJ2mHkK3qOpdx30LWeBpO",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -154.25,
			"y": 1088.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 224478552,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 270,
			"versionNonce": 804576235,
			"isDeleted": false,
			"id": "OuItpAniuLPvNilQP5Xnj",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 187.75,
			"y": 1093.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 218946088,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 227,
			"versionNonce": 457665605,
			"isDeleted": false,
			"id": "3CGntIANcMcH5g8tW9H6W",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -485.25,
			"y": 1510.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 1640894040,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 225,
			"versionNonce": 812131979,
			"isDeleted": false,
			"id": "Q80PNz30RP86RPgpg9KeC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -147.25,
			"y": 1514.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 2018162216,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 220,
			"versionNonce": 108764069,
			"isDeleted": false,
			"id": "oSBRO0d_4RXklogriXD_s",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 200.75,
			"y": 1515.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#a5d8ff",
			"width": 213,
			"height": 203,
			"seed": 1609844008,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 380,
			"versionNonce": 1700338987,
			"isDeleted": false,
			"id": "GNxRcNwxWQoiK5nwDqJv-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -209.75,
			"y": 859.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffec99",
			"width": 334,
			"height": 139,
			"seed": 1172207960,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "rectangle",
			"version": 389,
			"versionNonce": 238214917,
			"isDeleted": false,
			"id": "tLfTK8juKAoChwDEk_ruJ",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -220.75,
			"y": 1329.0546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffec99",
			"width": 334,
			"height": 139,
			"seed": 1232539432,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 3
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1325,
			"versionNonce": 1244807115,
			"isDeleted": false,
			"id": "PVMjaehhj-ke8b3wn9eb0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -844.75,
			"y": 596.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 1870115112,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1222,
			"versionNonce": 1491777125,
			"isDeleted": false,
			"id": "_y2vZfRbPcRIedz99mgty",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -872.75,
			"y": 1085.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 375704408,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1260,
			"versionNonce": 281908549,
			"isDeleted": false,
			"id": "kvBK-Tnv78iE7O-WxPO0d",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -870.75,
			"y": 17.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 2142737960,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640686808,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1421,
			"versionNonce": 1634771397,
			"isDeleted": false,
			"id": "Rbe1bpyfbCg8UhFt_1viL",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 600.25,
			"y": 2.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 526664792,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1338,
			"versionNonce": 615975179,
			"isDeleted": false,
			"id": "QJUBTsY3VB9ny8JMmhTuq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 558.25,
			"y": 597.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 1750220072,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 1240,
			"versionNonce": 1826758949,
			"isDeleted": false,
			"id": "YGhUpK2UBlobm6hbh0Ltu",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 576.25,
			"y": 1110.5546875,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ff9e9e",
			"width": 208,
			"height": 196,
			"seed": 1537974616,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640623258,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 633,
			"versionNonce": 297310981,
			"isDeleted": false,
			"id": "34tNpJZV9bLn212LMnPdg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -165.75,
			"y": -541.1413352272723,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#a5d8ff",
			"width": 217,
			"height": 202,
			"seed": 741493989,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "RSHFh-voxygHdRssCis0-",
					"type": "arrow"
				}
			],
			"updated": 1703640654834,
			"link": null,
			"locked": false
		},
		{
			"type": "arrow",
			"version": 304,
			"versionNonce": 418593002,
			"isDeleted": false,
			"id": "N382cTwh-dxVcP8hE2pwy",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.95595719249687,
			"y": -730.2020827486383,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 2.248960900812726,
			"height": 200.9011131653159,
			"seed": 1689911531,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1706049057291,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "MZBhjrqgxdBcCupAXF5V6",
				"gap": 15.546599468993023,
				"focus": -0.024049632368973506
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					2.248960900812726,
					200.9011131653159
				]
			]
		},
		{
			"type": "arrow",
			"version": 48,
			"versionNonce": 1455549323,
			"isDeleted": false,
			"id": "RSHFh-voxygHdRssCis0-",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -51.79545454545473,
			"y": -327.41406249999966,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 0,
			"height": 136.36363636363637,
			"seed": 774943851,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640664291,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "34tNpJZV9bLn212LMnPdg",
				"focus": -0.05027230833682275,
				"gap": 11.843189213489708
			},
			"endBinding": {
				"elementId": "0nPT6TFRBB61_p4oOMDbv",
				"focus": -0.01116971765436155,
				"gap": 13.968749999999773
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					0,
					136.36363636363637
				]
			]
		},
		{
			"type": "arrow",
			"version": 75,
			"versionNonce": 1937941125,
			"isDeleted": false,
			"id": "0XYyJhzyTS6CFHzpmlHSI",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -211.79545454545473,
			"y": -58.32315340909054,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 123.63636363636351,
			"height": 67.27272727272725,
			"seed": 128054123,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640669283,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "0nPT6TFRBB61_p4oOMDbv",
				"focus": 0.2032298869961206,
				"gap": 15.136363636363967
			},
			"endBinding": {
				"elementId": "Fq4RLqCvLl0Xvk3yie56b",
				"focus": -0.7097063485158993,
				"gap": 8.48212086903439
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-123.63636363636351,
					67.27272727272725
				]
			]
		},
		{
			"type": "arrow",
			"version": 19,
			"versionNonce": 1954545867,
			"isDeleted": false,
			"id": "YmbB9kJz50t6PG0-hmwsP",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.06818181818198,
			"y": -45.59588068181779,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 3.6363636363637397,
			"height": 41.818181818181756,
			"seed": 155551045,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640672664,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "0nPT6TFRBB61_p4oOMDbv",
				"focus": 0.10032420984034224,
				"gap": 13.485795454545723
			},
			"endBinding": {
				"elementId": "vm0OJZloSCGZJ-NNQehDC",
				"focus": 0.024953692185227576,
				"gap": 8.57118762011767
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					3.6363636363637397,
					41.818181818181756
				]
			]
		},
		{
			"type": "arrow",
			"version": 45,
			"versionNonce": 595913893,
			"isDeleted": false,
			"id": "ySgvwhSiSM9mNlF9reXC9",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 104.56818181818176,
			"y": -54.686789772727025,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 96.36363636363649,
			"height": 67.27272727272725,
			"seed": 1430817291,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640676264,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "0nPT6TFRBB61_p4oOMDbv",
				"focus": -0.27668676380653323,
				"gap": 8.22727272727252
			},
			"endBinding": {
				"elementId": "RctvImppAUYYKN5WEw_gP",
				"focus": 0.3704324393490379,
				"gap": 15.87253260531368
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					96.36363636363649,
					67.27272727272725
				]
			]
		},
		{
			"type": "arrow",
			"version": 80,
			"versionNonce": 1724106603,
			"isDeleted": false,
			"id": "p0TY-9ZLDJH9xDemy-pbL",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -317.25,
			"y": 216.22230113636397,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 198.18181818181802,
			"height": 130.90909090909076,
			"seed": 35277509,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640692576,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Fq4RLqCvLl0Xvk3yie56b",
				"focus": 0.538389624973676,
				"gap": 15.245977689415014
			},
			"endBinding": {
				"elementId": "Jux3vhwI8I6UjxBYjrlKP",
				"focus": 0.13310650897865914,
				"gap": 1.4232954545452685
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					198.18181818181802,
					130.90909090909076
				]
			]
		},
		{
			"type": "arrow",
			"version": 117,
			"versionNonce": 1834759339,
			"isDeleted": false,
			"id": "JY4H-_crTfdUtAJ7JfEkz",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -49.97727272727275,
			"y": 228.94957386363694,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 5.454545454545496,
			"height": 119.99999999999977,
			"seed": 386082987,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640717343,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "vm0OJZloSCGZJ-NNQehDC",
				"focus": 0.07108127213067122,
				"gap": 17.407642768719626
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					5.454545454545496,
					119.99999999999977
				]
			]
		},
		{
			"type": "arrow",
			"version": 157,
			"versionNonce": 1667455269,
			"isDeleted": false,
			"id": "C8_-PDL3V7zVYOEvoWyCK",
			"fillStyle": "solid",
			"strokeWidth": 4,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 204.56818181818176,
			"y": 203.49502840909122,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "#ff9e9e",
			"width": 170.909090909091,
			"height": 138.18181818181824,
			"seed": 1732076165,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1703640723333,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "RctvImppAUYYKN5WEw_gP",
				"focus": -0.3138352277556747,
				"gap": 13.81205540691522
			},
			"endBinding": {
				"elementId": "Jux3vhwI8I6UjxBYjrlKP",
				"focus": -0.05090288450171356,
				"gap": 6.877840909090537
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-170.909090909091,
					138.18181818181824
				]
			]
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "#ff9e9e",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 4,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 2163.361111111111,
		"scrollY": 1116.3218907828282,
		"zoom": {
			"value": 0.45
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%